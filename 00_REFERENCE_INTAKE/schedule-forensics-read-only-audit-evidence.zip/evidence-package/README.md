# Forensic audit evidence bundle

This bundle supports the read-only falsification audit of
`polittdj/Schedule-Manipulation-Analysis-Tool-Experiment` at commit
`08c538334c761124539b335e46e303898c4e6fbc`, version `1.0.123`.

Contents:

- `report/forensic-audit-report.md` — the complete 11-section report, including exact
  evidence-producing commands.
- `tests/` — every independently authored Python and Java probe in full.
- `results/` — raw JSON, CSV, stdout, and stderr evidence.
- `SHA256SUMS` — hashes for every bundled file.

The reviewed repository and supplied source/reference schedules are intentionally not duplicated
in this compact bundle. Their paths, sizes, and SHA-256 values are recorded in the report and
inventory. Generated 21.8 MB MSPDI files and benchmark SQLite caches are also omitted; their
semantic hashes and measurements are retained in the raw result JSON.

No file in this bundle was written inside the reviewed repository.
