#!/usr/bin/env python3
"""Read-only recursive evidence inventory for the audited tree and reference archives."""

from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import mimetypes
import subprocess
import sys
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from docx import Document
from openpyxl import load_workbook
from PIL import Image
from pypdf import PdfReader


TEXT_EXTS = {
    ".css",
    ".csv",
    ".html",
    ".ini",
    ".java",
    ".js",
    ".json",
    ".md",
    ".py",
    ".rst",
    ".toml",
    ".ts",
    ".txt",
    ".xml",
    ".yaml",
    ".yml",
}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def text_stats(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    decoded: str | None = None
    encoding = ""
    for candidate in ("utf-8-sig", "utf-16", "cp1252"):
        try:
            decoded = raw.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            pass
    if decoded is None:
        return {"parse": "text", "read": True, "decoded": False}
    return {
        "parse": "text",
        "read": True,
        "decoded": True,
        "encoding": encoding,
        "characters": len(decoded),
        "lines": decoded.count("\n") + bool(decoded),
        "nonblank_lines": sum(bool(line.strip()) for line in decoded.splitlines()),
    }


def xml_stats(path: Path) -> dict[str, Any]:
    root = ET.parse(path).getroot()
    tags = Counter(elem.tag.rsplit("}", 1)[-1] for elem in root.iter())
    return {
        "parse": "xml",
        "read": True,
        "root": root.tag.rsplit("}", 1)[-1],
        "elements": sum(tags.values()),
        "top_tags": tags.most_common(12),
    }


def xlsx_stats(path: Path) -> dict[str, Any]:
    book = load_workbook(path, read_only=True, data_only=False)
    sheets: list[dict[str, Any]] = []
    total_cells = 0
    nonempty = 0
    formulas = 0
    for ws in book.worksheets:
        sheet_nonempty = 0
        sheet_formulas = 0
        for row in ws.iter_rows():
            for cell in row:
                total_cells += 1
                if cell.value is not None:
                    nonempty += 1
                    sheet_nonempty += 1
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    formulas += 1
                    sheet_formulas += 1
        sheets.append(
            {
                "name": ws.title,
                "max_row": ws.max_row,
                "max_column": ws.max_column,
                "nonempty": sheet_nonempty,
                "formulas": sheet_formulas,
            }
        )
    book.close()
    return {
        "parse": "xlsx",
        "read": True,
        "sheets": sheets,
        "cells_visited": total_cells,
        "nonempty": nonempty,
        "formulas": formulas,
    }


def docx_stats(path: Path) -> dict[str, Any]:
    doc = Document(path)
    paragraphs = [p.text for p in doc.paragraphs]
    table_cells = [cell.text for table in doc.tables for row in table.rows for cell in row.cells]
    return {
        "parse": "docx",
        "read": True,
        "paragraphs": len(paragraphs),
        "tables": len(doc.tables),
        "table_cells": len(table_cells),
        "characters": sum(map(len, paragraphs)) + sum(map(len, table_cells)),
        "nonblank_paragraphs": sum(bool(p.strip()) for p in paragraphs),
    }


def pdf_stats(path: Path) -> dict[str, Any]:
    reader = PdfReader(path)
    characters = 0
    pages_with_text = 0
    errors = 0
    for page in reader.pages:
        try:
            text = page.extract_text() or ""
            characters += len(text)
            pages_with_text += bool(text.strip())
        except Exception:
            errors += 1
    return {
        "parse": "pdf",
        "read": True,
        "pages": len(reader.pages),
        "pages_with_text": pages_with_text,
        "characters": characters,
        "page_errors": errors,
        "encrypted": reader.is_encrypted,
    }


def image_stats(path: Path) -> dict[str, Any]:
    with Image.open(path) as image:
        image.load()
        return {
            "parse": "image",
            "read": True,
            "format": image.format,
            "width": image.width,
            "height": image.height,
            "mode": image.mode,
        }


def zip_stats(path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        unsafe = [
            m.filename
            for m in members
            if Path(m.filename).is_absolute() or ".." in Path(m.filename).parts
        ]
        return {
            "parse": "zip",
            "read": True,
            "members": len(members),
            "uncompressed_bytes": sum(m.file_size for m in members),
            "compressed_bytes": sum(m.compress_size for m in members),
            "unsafe_members": unsafe,
        }


def ole_stats(path: Path) -> dict[str, Any]:
    import olefile

    with olefile.OleFileIO(path) as ole:
        streams = ole.listdir()
        total = 0
        for stream in streams:
            try:
                total += ole.get_size(stream)
            except OSError:
                pass
        return {
            "parse": "ole",
            "read": True,
            "streams": len(streams),
            "stream_bytes": total,
            "stream_names": ["/".join(item) for item in streams[:40]],
        }


def gzip_stats(path: Path) -> dict[str, Any]:
    h = hashlib.sha256()
    size = 0
    with gzip.open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
            size += len(block)
    return {
        "parse": "gzip",
        "read": True,
        "uncompressed_bytes": size,
        "uncompressed_sha256": h.hexdigest(),
    }


def looks_textual(path: Path) -> bool:
    sample = path.read_bytes()[:65536]
    if not sample:
        return True
    if b"\0" in sample:
        return False
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            decoded = sample.decode(encoding)
            return sum(char.isprintable() or char in "\r\n\t" for char in decoded) / len(decoded) > 0.9
        except UnicodeDecodeError:
            pass
    return False


def parse_file(path: Path) -> dict[str, Any]:
    suffix = path.suffix.lower()
    head = path.read_bytes()[:16]
    try:
        # Dispatch by content first: the evidence bundle intentionally contains several files
        # whose extensions do not match their payloads.
        if head.startswith(b"%PDF"):
            return pdf_stats(path)
        if head.startswith(b"\x89PNG\r\n\x1a\n") or head.startswith(b"\xff\xd8\xff"):
            return image_stats(path)
        if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
            return ole_stats(path)
        if head.startswith(b"\x1f\x8b"):
            return gzip_stats(path)
        if head.startswith(b"PK\x03\x04"):
            if suffix == ".xlsx":
                return xlsx_stats(path)
            if suffix == ".docx":
                return docx_stats(path)
            return zip_stats(path)
        if looks_textual(path):
            if suffix == ".xml" or head.lstrip().startswith(b"<?xml"):
                return {**text_stats(path), **xml_stats(path)}
            return text_stats(path)
        if suffix == ".xml":
            return {**text_stats(path), **xml_stats(path)}
        return {"parse": "binary", "read": True, "bytes_read": len(path.read_bytes())}
    except Exception as exc:
        return {
            "parse": suffix.lstrip(".") or "unknown",
            "read": False,
            "error": f"{type(exc).__name__}: {exc}",
        }


def git_files(repo: Path) -> list[Path]:
    output = subprocess.check_output(["git", "ls-files", "-z"], cwd=repo)
    return [repo / item.decode("utf-8") for item in output.split(b"\0") if item]


def all_files(root: Path) -> list[Path]:
    return sorted(path for path in root.rglob("*") if path.is_file())


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--reference", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    groups: list[tuple[str, Path, list[Path]]] = [("repository", args.repo, git_files(args.repo))]
    groups.extend((f"reference-{index}", root, all_files(root)) for index, root in enumerate(args.reference, 1))

    records: list[dict[str, Any]] = []
    parsed_by_hash: dict[str, dict[str, Any]] = {}
    for group, root, files in groups:
        for index, path in enumerate(files, 1):
            sha = digest(path)
            if sha not in parsed_by_hash:
                parsed_by_hash[sha] = parse_file(path)
            records.append(
                {
                    "group": group,
                    "path": path.relative_to(root).as_posix(),
                    "size": path.stat().st_size,
                    "sha256": sha,
                    "mime": mimetypes.guess_type(path.name)[0],
                    "duplicate_of": next(
                        (
                            r["path"]
                            for r in records
                            if r["sha256"] == sha and r["group"] == group
                        ),
                        None,
                    ),
                    **parsed_by_hash[sha],
                }
            )
            if index % 100 == 0:
                print(f"{group}: {index}/{len(files)}", file=sys.stderr, flush=True)

    summary = {
        "physical_files": len(records),
        "unique_hashes": len(parsed_by_hash),
        "bytes": sum(record["size"] for record in records),
        "groups": {
            group: {
                "files": sum(record["group"] == group for record in records),
                "bytes": sum(record["size"] for record in records if record["group"] == group),
                "read_failures": sum(
                    record["group"] == group and not record["read"] for record in records
                ),
            }
            for group, _root, _files in groups
        },
        "extensions": dict(
            sorted(Counter(Path(record["path"]).suffix.lower() for record in records).items())
        ),
        "read_failures": [
            {
                "group": record["group"],
                "path": record["path"],
                "sha256": record["sha256"],
                "error": record.get("error"),
            }
            for record in records
            if not record["read"]
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps({"summary": summary, "files": records}, indent=2, default=str),
        encoding="utf-8",
    )
    csv_path = args.output.with_suffix(".csv")
    with csv_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "group",
                "path",
                "size",
                "sha256",
                "mime",
                "duplicate_of",
                "parse",
                "read",
                "error",
            ],
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(records)
    print(json.dumps(summary, indent=2))
    return int(bool(summary["read_failures"]))


if __name__ == "__main__":
    raise SystemExit(main())
