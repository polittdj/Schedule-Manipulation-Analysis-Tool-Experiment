#!/usr/bin/env python3
"""Re-run the shipped MPP path with an explicit writable Java/Python temp directory.

The Work Mode sandbox does not provide /tmp. MPXJ's UniversalProjectReader materializes an
OLE stream through java.io.tmpdir, so an explicit directory is required to distinguish an
environmental failure from a converter failure.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Callable


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def distribution(values: list[float]) -> dict[str, Any]:
    ordered = sorted(values)
    return {
        "trials": len(values),
        "values": [round(value, 3) for value in values],
        "median": round(statistics.median(values), 3),
        "p95_nearest_rank": round(ordered[math.ceil(0.95 * len(ordered)) - 1], 3),
        "min": round(min(values), 3),
        "max": round(max(values), 3),
    }


def parsed_semantic_hash(xml_path: Path) -> str:
    from schedule_forensics.importers.mspdi import parse_mspdi

    schedule = parse_mspdi(xml_path)
    # The trial filename becomes both Schedule.source_file and Schedule.name. Those are harness
    # artifacts, not converter semantics, so normalize them before comparing independent trials.
    schedule = schedule.model_copy(
        update={
            "source_file": "normalized-converter-output.xml",
            "name": "normalized-converter-output",
        }
    )
    sidecar = Path(str(xml_path) + ".views.json")
    views: Any = None
    if sidecar.is_file():
        views = json.loads(sidecar.read_text(encoding="utf-8"))
    payload = {
        "schedule": json.loads(schedule.model_dump_json()),
        "views": views,
    }
    return sha_bytes(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode())


def measured_trials(
    operation: Callable[[int], dict[str, Any]],
    *,
    warmups: int = 1,
    measured: int = 5,
) -> dict[str, Any]:
    for index in range(warmups):
        operation(-(index + 1))
    rows: list[dict[str, Any]] = []
    elapsed: list[float] = []
    for index in range(measured):
        gc.collect()
        started = time.perf_counter()
        row = operation(index + 1)
        elapsed.append((time.perf_counter() - started) * 1000)
        rows.append(row)
    return {
        "latency_ms": distribution(elapsed),
        "rows": rows,
        "all_returncode_zero": all(row.get("returncode") == 0 for row in rows),
        "all_outputs_exist": all(row.get("output_exists") for row in rows),
        "raw_output_identical": len({row.get("xml_sha256") for row in rows}) == 1,
        "semantic_output_identical": len({row.get("semantic_sha256") for row in rows}) == 1,
    }


def one_shot_benchmark(
    java: Path,
    classpath: str,
    mpp: Path,
    output_dir: Path,
    java_tmp: Path,
) -> dict[str, Any]:
    def operation(index: int) -> dict[str, Any]:
        suffix = f"warmup-{abs(index)}" if index < 0 else f"trial-{index}"
        target = output_dir / f"one-shot-{suffix}.xml"
        target.unlink(missing_ok=True)
        Path(str(target) + ".views.json").unlink(missing_ok=True)
        command = [
            str(java),
            f"-Djava.io.tmpdir={java_tmp}",
            "-cp",
            classpath,
            "MpxjToMspdi",
            str(mpp),
            str(target),
        ]
        proc = subprocess.run(command, capture_output=True, text=True, check=False)
        return {
            "returncode": proc.returncode,
            "stdout": proc.stdout[-500:],
            "stderr": proc.stderr[-500:],
            "output_exists": target.is_file(),
            "xml_bytes": target.stat().st_size if target.is_file() else None,
            "xml_sha256": sha_file(target) if target.is_file() else None,
            "views_bytes": (
                Path(str(target) + ".views.json").stat().st_size
                if Path(str(target) + ".views.json").is_file()
                else None
            ),
            "semantic_sha256": parsed_semantic_hash(target) if target.is_file() else None,
        }

    return measured_trials(operation)


def server_benchmark(
    java: Path,
    classpath: str,
    mpp: Path,
    output_dir: Path,
    java_tmp: Path,
) -> dict[str, Any]:
    command = [
        str(java),
        f"-Djava.io.tmpdir={java_tmp}",
        "-Xmx1g",
        "-cp",
        classpath,
        "MpxjToMspdi",
        "--server",
    ]
    startup_started = time.perf_counter()
    proc = subprocess.Popen(
        command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        bufsize=1,
    )
    assert proc.stdout is not None
    ready_lines: list[str] = []
    while True:
        line = proc.stdout.readline()
        if not line:
            raise RuntimeError("converter server exited before READY")
        ready_lines.append(line.rstrip())
        if line.startswith("@@SF@@ READY"):
            break
    startup_ms = (time.perf_counter() - startup_started) * 1000

    def operation(index: int) -> dict[str, Any]:
        suffix = f"warmup-{abs(index)}" if index < 0 else f"trial-{index}"
        target = output_dir / f"server-{suffix}.xml"
        target.unlink(missing_ok=True)
        Path(str(target) + ".views.json").unlink(missing_ok=True)
        assert proc.stdin is not None
        proc.stdin.write(f"{mpp}\t{target}\n")
        proc.stdin.flush()
        status_lines: list[str] = []
        while True:
            line = proc.stdout.readline()
            if not line:
                raise RuntimeError("converter server exited during conversion")
            status_lines.append(line.rstrip())
            if line.startswith("@@SF@@ "):
                break
        status = status_lines[-1]
        ok = status == "@@SF@@ OK"
        return {
            "returncode": 0 if ok else 2,
            "status_lines": status_lines,
            "output_exists": target.is_file(),
            "xml_bytes": target.stat().st_size if target.is_file() else None,
            "xml_sha256": sha_file(target) if target.is_file() else None,
            "views_bytes": (
                Path(str(target) + ".views.json").stat().st_size
                if Path(str(target) + ".views.json").is_file()
                else None
            ),
            "semantic_sha256": parsed_semantic_hash(target) if target.is_file() else None,
        }

    try:
        result = measured_trials(operation)
    finally:
        if proc.stdin is not None:
            proc.stdin.write("__QUIT__\n")
            proc.stdin.flush()
        proc.wait(timeout=10)
    stderr = proc.stderr.read() if proc.stderr is not None else ""
    result.update(
        {
            "startup_ms": round(startup_ms, 3),
            "ready_lines": ready_lines,
            "server_returncode": proc.returncode,
            "server_stderr": stderr[-1000:],
        }
    )
    return result


def route_benchmark(mpp: Path, output_dir: Path) -> dict[str, Any]:
    from performance_matrix import timed_trials, upload_once
    import schedule_forensics.web.app as app_module

    raw = mpp.read_bytes()
    original = app_module._parse_upload
    parse_calls = {"count": 0}

    def counted_parse(name: str, data: bytes) -> Any:
        parse_calls["count"] += 1
        return original(name, data)

    app_module._parse_upload = counted_parse
    try:
        cold_index = 0

        def cold() -> tuple[bytes, dict[str, Any]]:
            nonlocal cold_index
            cold_index += 1
            before = parse_calls["count"]
            payload, meta = upload_once(
                [("Large Test File2.mpp", raw)],
                output_dir / f"route-cold-{cold_index}.sqlite3",
                reset_cache=True,
            )
            return payload, {**meta, "parse_upload_calls": parse_calls["count"] - before}

        cold_result = timed_trials(cold, measured=5, warmups=1)

        warm_cache = output_dir / "route-warm.sqlite3"
        upload_once(
            [("Large Test File2.mpp", raw)],
            warm_cache,
            reset_cache=True,
        )

        def warm() -> tuple[bytes, dict[str, Any]]:
            before = parse_calls["count"]
            payload, meta = upload_once(
                [("Large Test File2.mpp", raw)],
                warm_cache,
                reset_cache=False,
            )
            return payload, {**meta, "parse_upload_calls": parse_calls["count"] - before}

        warm_result = timed_trials(warm, measured=5, warmups=1)
    finally:
        app_module._parse_upload = original

    return {
        "one_large_mpp_cold_cache": cold_result,
        "one_large_mpp_warm_parse_cache": warm_result,
        "warm_cache_skipped_conversion": all(
            row["parse_upload_calls"] == 0 for row in warm_result["metadata"]
        ),
        "cold_cache_invoked_parse": all(
            row["parse_upload_calls"] == 1 for row in cold_result["metadata"]
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--mpp", required=True, type=Path)
    parser.add_argument("--java", required=True, type=Path)
    parser.add_argument("--temp", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    args.temp.mkdir(parents=True, exist_ok=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    os.environ["TMPDIR"] = str(args.temp)
    os.environ["JAVA_TOOL_OPTIONS"] = f"-Djava.io.tmpdir={args.temp}"
    os.environ["SF_MPXJ_HOME"] = str(args.repo / "tools" / "mpxj")
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    sys.path.insert(0, str(Path(__file__).resolve().parent))

    classpath = os.pathsep.join(
        [
            str(args.repo / "tools" / "mpxj" / "classes"),
            str(args.repo / "tools" / "mpxj" / "lib" / "*"),
        ]
    )
    results: dict[str, Any] = {
        "source": {
            "path": str(args.mpp),
            "bytes": args.mpp.stat().st_size,
            "sha256": sha_file(args.mpp),
        },
        "environment": {
            "java": str(args.java),
            "java_tmp": str(args.temp),
            "python_tmp": os.environ["TMPDIR"],
            "java_tool_options": os.environ["JAVA_TOOL_OPTIONS"],
        },
    }

    print("one-shot converter", flush=True)
    results["one_shot_converter"] = one_shot_benchmark(
        args.java, classpath, args.mpp, args.output_dir, args.temp
    )
    args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("persistent converter server", flush=True)
    results["persistent_converter_server"] = server_benchmark(
        args.java, classpath, args.mpp, args.output_dir, args.temp
    )
    args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print("application upload route", flush=True)
    results["application_upload_route"] = route_benchmark(args.mpp, args.output_dir)
    args.output.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps(results, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
