import org.mpxj.ProjectFile;
import org.mpxj.mpp.MPPReader;
import org.mpxj.mspdi.MSPDIWriter;

public final class MpxjDirectConvert {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            throw new IllegalArgumentException("usage: MpxjDirectConvert <input.mpp> <output.xml>");
        }
        ProjectFile project = new MPPReader().read(args[0]);
        if (project == null) {
            throw new IllegalStateException("MPPReader returned null");
        }
        new MSPDIWriter().write(project, args[1]);
        System.out.println("tasks=" + project.getTasks().size());
        System.out.println("calendars=" + project.getCalendars().size());
        System.out.println("resources=" + project.getResources().size());
    }
}
