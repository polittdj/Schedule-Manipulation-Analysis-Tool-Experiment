#!/usr/bin/env python3
"""Reproducible server-side performance probes for P1-P6.

All outputs and caches are directed outside the reviewed repository. Browser-only metrics are
explicitly marked unavailable when no browser executable is present.
"""

from __future__ import annotations

import argparse
import contextlib
import copy
import datetime as dt
import gc
import hashlib
import json
import logging
import math
import os
import platform
import resource
import shutil
import statistics
import subprocess
import sys
import tempfile
import threading
import time
import tracemalloc
from dataclasses import asdict, dataclass, fields, is_dataclass
from html.parser import HTMLParser
from pathlib import Path
from types import FunctionType, MethodType, ModuleType
from typing import Any, Callable, Iterable

from fastapi.testclient import TestClient

import schedule_forensics.engine.cache as cache_module
import schedule_forensics.web.state as state_module
from schedule_forensics.engine.cache import ScheduleCache, content_hash, engine_version
from schedule_forensics.engine.cpm import compute_cpm
from schedule_forensics.engine.memory import estimate_resident_bytes
from schedule_forensics.importers import mspdi
from schedule_forensics.importers.mspdi import parse_mspdi
from schedule_forensics.model.calendar import Calendar
from schedule_forensics.model.relationship import Relationship
from schedule_forensics.model.schedule import Schedule
from schedule_forensics.model.task import Task
from schedule_forensics.web.app import create_app
from schedule_forensics.web.offload import shutdown_offload
from schedule_forensics.web.state import SessionState


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def summary(values: list[float]) -> dict[str, Any]:
    ordered = sorted(values)
    return {
        "trials": len(values),
        "values": [round(value, 3) for value in values],
        "median": round(statistics.median(values), 3),
        "p95_nearest_rank": round(ordered[math.ceil(0.95 * len(ordered)) - 1], 3),
        "min": round(min(values), 3),
        "max": round(max(values), 3),
    }


def timed_trials(
    operation: Callable[[], tuple[bytes, dict[str, Any]]],
    *,
    measured: int = 5,
    warmups: int = 1,
) -> dict[str, Any]:
    for _ in range(warmups):
        operation()
    times: list[float] = []
    hashes: list[str] = []
    sizes: list[int] = []
    metadata: list[dict[str, Any]] = []
    for _ in range(measured):
        gc.collect()
        started = time.perf_counter()
        payload, meta = operation()
        times.append((time.perf_counter() - started) * 1000)
        hashes.append(sha_bytes(payload))
        sizes.append(len(payload))
        metadata.append(meta)
    return {
        "latency_ms": summary(times),
        "payload_bytes": sizes,
        "output_hashes": hashes,
        "output_identical": len(set(hashes)) == 1,
        "metadata": metadata,
    }


class TagCounter(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.nodes = 0
        self.svg = 0
        self.scripts = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.nodes += 1
        if tag in {
            "svg",
            "path",
            "line",
            "rect",
            "circle",
            "ellipse",
            "polyline",
            "polygon",
            "text",
            "g",
        }:
            self.svg += 1
        if tag == "script":
            self.scripts += 1


def response_meta(response: Any) -> dict[str, Any]:
    kind = response.headers.get("content-type", "")
    result: dict[str, Any] = {"status": response.status_code, "content_type": kind}
    if "html" in kind:
        parser = TagCounter()
        parser.feed(response.text)
        result.update(
            {
                "server_html_nodes": parser.nodes,
                "server_svg_elements": parser.svg,
                "script_tags": parser.scripts,
            }
        )
    if "json" in kind:
        started = time.perf_counter()
        parsed = json.loads(response.content)
        result["python_json_parse_ms"] = (time.perf_counter() - started) * 1000
        result["top_level_shape"] = (
            sorted(parsed) if isinstance(parsed, dict) else type(parsed).__name__
        )
    return result


@contextlib.contextmanager
def count_cpm_calls() -> Iterable[dict[str, int]]:
    """Patch every imported alias of the trusted chokepoint during one request."""
    original = compute_cpm
    counts = {"compute_cpm": 0, "full_analysis": 0}

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        counts["compute_cpm"] += 1
        return original(*args, **kwargs)

    original_analysis = state_module._compute_analysis

    def analysis_wrapper(*args: Any, **kwargs: Any) -> Any:
        counts["full_analysis"] += 1
        return original_analysis(*args, **kwargs)

    patched: list[tuple[ModuleType, str, Any]] = []
    for module in list(sys.modules.values()):
        name = getattr(module, "__name__", "")
        if not name.startswith("schedule_forensics"):
            continue
        if getattr(module, "compute_cpm", None) is original:
            patched.append((module, "compute_cpm", original))
            setattr(module, "compute_cpm", wrapper)
    state_module._compute_analysis = analysis_wrapper
    try:
        yield counts
    finally:
        state_module._compute_analysis = original_analysis
        for module, name, value in patched:
            setattr(module, name, value)


def deep_size(value: Any, seen: set[int] | None = None) -> int:
    """Conservative recursive Python-object size; shared references count once."""
    if seen is None:
        seen = set()
    if isinstance(value, (str, bytes, bytearray, memoryview, int, float, bool, type(None))):
        return sys.getsizeof(value)
    if isinstance(value, (ModuleType, FunctionType, MethodType, type)):
        return 0
    ident = id(value)
    if ident in seen:
        return 0
    seen.add(ident)
    total = sys.getsizeof(value)
    if isinstance(value, dict):
        return total + sum(deep_size(key, seen) + deep_size(item, seen) for key, item in value.items())
    if isinstance(value, (list, tuple, set, frozenset)):
        return total + sum(deep_size(item, seen) for item in value)
    if is_dataclass(value):
        return total + sum(deep_size(getattr(value, field.name), seen) for field in fields(value))
    if hasattr(value, "__dict__"):
        total += deep_size(vars(value), seen)
    for slot in getattr(type(value), "__slots__", ()):
        if isinstance(slot, str) and hasattr(value, slot):
            total += deep_size(getattr(value, slot), seen)
    return total


def synthetic_schedule(
    count: int,
    *,
    name: str = "synthetic",
    project_title: str | None = "Synthetic project",
    status_shift_days: int = 0,
) -> Schedule:
    start = dt.datetime(2026, 1, 5, 8)
    tasks = tuple(
        Task(
            unique_id=index + 1,
            name=f"Task {index + 1}",
            wbs=f"1.{index + 1}",
            duration_minutes=60,
            remaining_duration_minutes=60,
            percent_complete=0,
            baseline_start=start,
            baseline_finish=start + dt.timedelta(minutes=60 * (index + 1)),
            budgeted_cost=1.0,
        )
        for index in range(count)
    )
    relationships = tuple(
        Relationship(predecessor_id=index, successor_id=index + 1)
        for index in range(1, count)
    )
    return Schedule(
        name=name,
        project_title=project_title,
        source_file=f"{name}.json",
        project_start=start,
        status_date=start + dt.timedelta(days=status_shift_days),
        calendar=Calendar(),
        tasks=tasks,
        relationships=relationships,
    )


def schedule_hash(schedule: Schedule) -> str:
    return sha_bytes(schedule.model_dump_json().encode())


def pipeline_profile(xml_path: Path) -> dict[str, Any]:
    phase_ms: dict[str, float] = {}
    gc_started: list[float] = []
    gc_total = 0.0

    def callback(phase: str, info: dict[str, Any]) -> None:
        nonlocal gc_total
        if phase == "start":
            gc_started.append(time.perf_counter())
        elif gc_started:
            gc_total += time.perf_counter() - gc_started.pop()

    gc.callbacks.append(callback)
    baseline_rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    tracemalloc.start()
    try:
        begin = time.perf_counter()
        raw = xml_path.read_bytes()
        phase_ms["read"] = (time.perf_counter() - begin) * 1000
        begin = time.perf_counter()
        text = raw.decode("utf-8-sig", errors="replace")
        phase_ms["decode"] = (time.perf_counter() - begin) * 1000
        real_fromstring = mspdi.ET.fromstring

        def timed_fromstring(payload: str) -> Any:
            started = time.perf_counter()
            root = real_fromstring(payload)
            phase_ms["xml_tree"] = (time.perf_counter() - started) * 1000
            return root

        mspdi.ET.fromstring = timed_fromstring
        begin = time.perf_counter()
        try:
            schedule = mspdi.parse_mspdi_text(text, source_file=xml_path.name)
        finally:
            mspdi.ET.fromstring = real_fromstring
        phase_ms["parse_text_total"] = (time.perf_counter() - begin) * 1000
        phase_ms["extract_validate_model_estimate"] = (
            phase_ms["parse_text_total"] - phase_ms["xml_tree"]
        )
        current, peak = tracemalloc.get_traced_memory()
        result = {
            "phase_ms": phase_ms,
            "file_bytes": len(raw),
            "bytes_object_size": sys.getsizeof(raw),
            "decoded_characters": len(text),
            "decoded_string_size": sys.getsizeof(text),
            "tasks": len(schedule.tasks),
            "relationships": len(schedule.relationships),
            "resources": len(schedule.resources),
            "calendars": len(schedule.calendars),
            "model_json_bytes": len(schedule.model_dump_json().encode()),
            "model_deep_size_bytes": deep_size(schedule),
            "resident_estimator_bytes": estimate_resident_bytes([schedule]),
            "tracemalloc_current_bytes": current,
            "tracemalloc_peak_bytes": peak,
            "maxrss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "baseline_maxrss_kib": baseline_rss,
            "gc_pause_ms": gc_total * 1000,
            "schedule_hash": schedule_hash(schedule),
        }
        return result
    finally:
        tracemalloc.stop()
        gc.callbacks.remove(callback)


def p1_pipeline(xml_path: Path) -> dict[str, Any]:
    # One unreported warm-up, then five independent process trials so max-RSS is not cumulative.
    command = [sys.executable, __file__, "--pipeline-worker", str(xml_path)]
    subprocess.run(command, check=True, capture_output=True, text=True)
    rows: list[dict[str, Any]] = []
    for _ in range(5):
        proc = subprocess.run(command, check=True, capture_output=True, text=True)
        rows.append(json.loads(proc.stdout))
    phases = {
        phase: summary([row["phase_ms"][phase] for row in rows])
        for phase in rows[0]["phase_ms"]
    }
    return {
        "source": {
            "path": str(xml_path),
            "sha256": sha_file(xml_path),
            "bytes": xml_path.stat().st_size,
        },
        "phase_ms": phases,
        "peak_rss_kib": summary([float(row["maxrss_kib"]) for row in rows]),
        "incremental_maxrss_kib": summary(
            [float(row["maxrss_kib"] - row["baseline_maxrss_kib"]) for row in rows]
        ),
        "tracemalloc_peak_bytes": summary(
            [float(row["tracemalloc_peak_bytes"]) for row in rows]
        ),
        "gc_pause_ms": summary([row["gc_pause_ms"] for row in rows]),
        "representations": [
            {
                key: row[key]
                for key in (
                    "file_bytes",
                    "bytes_object_size",
                    "decoded_characters",
                    "decoded_string_size",
                    "model_json_bytes",
                    "model_deep_size_bytes",
                    "resident_estimator_bytes",
                    "tasks",
                    "relationships",
                    "resources",
                    "calendars",
                    "schedule_hash",
                )
            }
            for row in rows
        ],
        "output_identical": len({row["schedule_hash"] for row in rows}) == 1,
        "streaming_prototype": {
            "status": "not attempted",
            "reason": (
                "A parse-only iterparse comparison cannot prove importer fidelity for saved views, "
                "extended attributes, assignments, exceptions, percent lag, and malformed XML. "
                "No streaming replacement is recommended without a full differential importer."
            ),
        },
    }


def reset_default_cache(path: Path) -> ScheduleCache:
    cache = ScheduleCache(path)
    cache_module._DEFAULT_CACHE = cache
    return cache


def upload_once(
    raw_files: list[tuple[str, bytes]],
    cache_path: Path,
    *,
    reset_cache: bool,
    file_meta: list[tuple[str | None, float | None]] | None = None,
) -> tuple[bytes, dict[str, Any]]:
    if reset_cache:
        cache_path.unlink(missing_ok=True)
        cache_path.with_name(cache_path.name + "-wal").unlink(missing_ok=True)
        cache_path.with_name(cache_path.name + "-shm").unlink(missing_ok=True)
    reset_default_cache(cache_path)
    state = SessionState()
    client = TestClient(create_app(state))
    files = [
        ("files", (name, data, "application/xml"))
        for name, data in raw_files
    ]
    tracemalloc.start()
    baseline = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    response = client.post(
        "/upload",
        files=files,
        data={"file_meta": json.dumps(file_meta or [])},
        headers={"x-sf-ajax": "1"},
    )
    _current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    model_hashes = [schedule_hash(schedule) for schedule in state.schedules.values()]
    payload = json.dumps(
        {
            "response": response.json(),
            "keys": list(state.schedules),
            "model_hashes": model_hashes,
        },
        sort_keys=True,
    ).encode()
    return payload, {
        "status": response.status_code,
        "accepted": len(state.schedules),
        "tracemalloc_peak_bytes": peak,
        "maxrss_growth_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss - baseline,
        "cache_bytes": cache_path.stat().st_size if cache_path.exists() else 0,
    }


def benchmark_uploads(xml_path: Path, output_dir: Path) -> dict[str, Any]:
    raw = xml_path.read_bytes()
    cache_path = output_dir / "upload-cache.sqlite3"
    cold_counter = 0

    def cold() -> tuple[bytes, dict[str, Any]]:
        nonlocal cold_counter
        cold_counter += 1
        return upload_once(
            [("large.xml", raw)],
            output_dir / f"cold-{cold_counter}.sqlite3",
            reset_cache=True,
        )

    cold_result = timed_trials(cold, measured=5, warmups=1)

    # Prime once; each measured run uses a fresh session so dedup does not short-circuit the cache.
    upload_once([("large.xml", raw)], cache_path, reset_cache=True)

    def warm() -> tuple[bytes, dict[str, Any]]:
        return upload_once([("large.xml", raw)], cache_path, reset_cache=False)

    warm_result = timed_trials(warm, measured=5, warmups=1)

    variants = [
        raw.replace(b"<Name>", f"<Name>Batch {index} ".encode(), 1)
        for index in range(3)
    ]

    batch_counter = 0

    def batch() -> tuple[bytes, dict[str, Any]]:
        nonlocal batch_counter
        batch_counter += 1
        return upload_once(
            [(f"batch-{index}.xml", data) for index, data in enumerate(variants, 1)],
            output_dir / f"batch-{batch_counter}.sqlite3",
            reset_cache=True,
            file_meta=[("batch-folder", float(index)) for index in range(3)],
        )

    batch_result = timed_trials(batch, measured=5, warmups=1)

    hash_trials = timed_trials(
        lambda: (
            content_hash(raw).encode(),
            {},
        ),
        measured=5,
        warmups=1,
    )

    schedule = parse_mspdi(xml_path)
    sqlite_cache = reset_default_cache(output_dir / "serialization.sqlite3")
    key = content_hash(raw)
    sqlite_cache.put_schedule(key, schedule)

    def get_cached() -> tuple[bytes, dict[str, Any]]:
        loaded = sqlite_cache.get_schedule(key)
        return (loaded.model_dump_json().encode() if loaded is not None else b""), {}

    get_result = timed_trials(get_cached, measured=5, warmups=1)
    put_result = timed_trials(
        lambda: (
            (sqlite_cache.put_schedule(key, schedule) or schedule_hash(schedule).encode()),
            {},
        ),
        measured=5,
        warmups=1,
    )
    return {
        "one_large_mspdi_cold_cache": cold_result,
        "one_large_mspdi_warm_parse_cache": warm_result,
        "three_distinct_large_mspdi_batch": batch_result,
        "sha256_hashing": hash_trials,
        "sqlite_model_get": get_result,
        "sqlite_model_put": put_result,
        "sqlite_bytes": (output_dir / "serialization.sqlite3").stat().st_size,
        "source_bytes": len(raw),
    }


def java_command(java: str, classpath: str, classname: str, *args: str) -> list[str]:
    return [java, "-cp", classpath, classname, *args]


def benchmark_mpp(
    repo: Path,
    java: str,
    classes: Path,
    direct_classpath: str,
    mpp: Path,
    output_dir: Path,
) -> dict[str, Any]:
    # Shipped converter command, expected to be independently classified by return code/output.
    converter_cp = str(repo / "tools/mpxj/classes") + os.pathsep + str(
        repo / "tools/mpxj/lib/*"
    )
    shipped_class = "MpxjToMspdi"

    def shipped() -> tuple[bytes, dict[str, Any]]:
        target = output_dir / "shipped-output.xml"
        target.unlink(missing_ok=True)
        proc = subprocess.run(
            java_command(java, converter_cp, shipped_class, str(mpp), str(target)),
            capture_output=True,
        )
        payload = proc.stdout + b"\n" + proc.stderr
        return payload, {"returncode": proc.returncode, "output_exists": target.exists()}

    shipped_result = timed_trials(shipped, measured=5, warmups=1)

    counter = 0

    def direct() -> tuple[bytes, dict[str, Any]]:
        nonlocal counter
        counter += 1
        target = output_dir / f"direct-{counter}.xml"
        proc = subprocess.run(
            java_command(
                java,
                direct_classpath,
                "MpxjDirectConvert",
                str(mpp),
                str(target),
            ),
            capture_output=True,
        )
        data = target.read_bytes() if target.exists() else proc.stdout + proc.stderr
        return data, {
            "returncode": proc.returncode,
            "stderr": proc.stderr.decode(errors="replace")[:500],
            "output_exists": target.exists(),
        }

    direct_result = timed_trials(direct, measured=5, warmups=1)
    return {
        "source": {"path": str(mpp), "bytes": mpp.stat().st_size, "sha256": sha_file(mpp)},
        "shipped_universal_reader": shipped_result,
        "external_format_specific_reader_prototype": direct_result,
    }


def route_benchmarks(schedule: Schedule) -> dict[str, Any]:
    v1 = schedule.model_copy(
        update={
            "source_file": "large-v1.xml",
            "status_date": schedule.status_date - dt.timedelta(days=7)
            if schedule.status_date
            else None,
        }
    )
    v2 = schedule.model_copy(update={"source_file": "large-v2.xml"})
    state = SessionState(
        schedules={"v1": v1, "v2": v2},
        sra_file="v2",
        sra_focus_uid=152,
    )
    client = TestClient(create_app(state))
    routes = {
        "dashboard": "/",
        "analysis": "/analysis/v2",
        "analysis_api_gantt_payload": "/api/analysis/v2",
        "performance": "/performance",
        "trend": "/trend",
        "trend_api": "/api/trend?target=152",
        "volatility": "/volatility",
        "evolution": "/evolution",
        "evolution_api": "/api/evolution?target=152",
        "path": "/path",
        "driving_path": "/driving-path?target=152&file=large-v2.xml",
        "resources": "/resources",
        "sra_page": "/sra?file=v2",
        "sra_ssi_api_100": "/api/sra/ssi?iterations=100",
        "sra_legacy_api_100": "/api/sra?iterations=100",
        "jcl_api_100": "/api/sra/jcl?iterations=100",
        "brief": "/brief",
        "briefing": "/briefing",
    }
    results: dict[str, Any] = {}
    for label, path in routes.items():
        def operation(path: str = path) -> tuple[bytes, dict[str, Any]]:
            with count_cpm_calls() as counts:
                response = client.get(path)
            return response.content, {**response_meta(response), **counts}

        results[label] = timed_trials(operation, measured=5, warmups=1)
    shutdown_offload()
    return {
        "schedule_tasks": len(schedule.tasks),
        "schedule_relationships": len(schedule.relationships),
        "routes": results,
        "cache_counts_after": {
            "analyses": len(state.analyses),
            "cpms": len(state.cpms),
            "summaries": len(state.summaries),
            "dash_cores": len(state.dash_cores),
            "dash_cards": len(state.dash_cards),
            "performance_memos": len(state._perf_memo),
        },
    }


def scaling_benchmarks() -> dict[str, Any]:
    task_curve: list[dict[str, Any]] = []
    for count in (250, 1000, 2000, 4000):
        schedule = synthetic_schedule(count, name=f"tasks-{count}")

        def cpm_operation(schedule: Schedule = schedule) -> tuple[bytes, dict[str, Any]]:
            result = compute_cpm(schedule)
            payload = json.dumps(
                {
                    "finish": result.project_finish,
                    "timings": [
                        (uid, timing.early_start, timing.early_finish, timing.total_float)
                        for uid, timing in sorted(result.timings.items())
                    ],
                },
                separators=(",", ":"),
            ).encode()
            return payload, {}

        task_curve.append(
            {
                "tasks": count,
                "relationships": len(schedule.relationships),
                "deep_size_bytes": deep_size(schedule),
                "resident_estimator_bytes": estimate_resident_bytes([schedule]),
                "cpm": timed_trials(cpm_operation, measured=5, warmups=1),
            }
        )

    version_curve: list[dict[str, Any]] = []
    base = synthetic_schedule(250, name="version-base")
    for count in (1, 2, 4, 8):
        schedules = {
            f"v{index}": base.model_copy(
                update={
                    "name": f"Version {index}",
                    "source_file": f"v{index}.json",
                    "status_date": base.status_date + dt.timedelta(days=index),
                }
            )
            for index in range(count)
        }

        def dashboard_cold(schedules: dict[str, Schedule] = schedules) -> tuple[bytes, dict[str, Any]]:
            state = SessionState(schedules=dict(schedules))
            response = TestClient(create_app(state)).get("/")
            return response.content, {
                "status": response.status_code,
                "state_deep_size_bytes": deep_size(state),
                "cpms": len(state.cpms),
                "dash_cores": len(state.dash_cores),
                "dash_cards": len(state.dash_cards),
            }

        version_curve.append(
            {
                "versions": count,
                "tasks_total": count * 250,
                "retained_schedule_bytes": deep_size(schedules),
                "dashboard_cold": timed_trials(dashboard_cold, measured=5, warmups=1),
            }
        )

    project_curve: list[dict[str, Any]] = []
    for count in (1, 2, 4, 8):
        schedules = {
            f"project-{index}": synthetic_schedule(
                250,
                name=f"Project {index}",
                project_title=f"Project {index}",
                status_shift_days=index,
            )
            for index in range(count)
        }

        def portfolio(schedules: dict[str, Schedule] = schedules) -> tuple[bytes, dict[str, Any]]:
            state = SessionState(schedules=dict(schedules))
            response = TestClient(create_app(state)).get("/portfolio")
            return response.content, {
                "status": response.status_code,
                "projects": len(state.projects()),
                "state_deep_size_bytes": deep_size(state),
            }

        project_curve.append(
            {
                "projects": count,
                "tasks_total": count * 250,
                "retained_schedule_bytes": deep_size(schedules),
                "portfolio": timed_trials(portfolio, measured=5, warmups=1),
            }
        )
    return {
        "tasks": task_curve,
        "versions": version_curve,
        "projects": project_curve,
    }


def retention_and_cache_multiplication(schedule: Schedule) -> dict[str, Any]:
    state = SessionState(schedules={"large": schedule}, sra_file="large")
    client = TestClient(create_app(state))
    stages: list[dict[str, Any]] = []

    def capture(label: str) -> None:
        stages.append(
            {
                "stage": label,
                "state_deep_size_bytes": deep_size(state),
                "raw_schedule_deep_size_bytes": deep_size(schedule),
                "resident_estimator_bytes": estimate_resident_bytes(list(state.schedules.values())),
                "cache_counts": {
                    "schedules": len(state.schedules),
                    "analyses": len(state.analyses),
                    "cpms": len(state.cpms),
                    "summaries": len(state.summaries),
                    "dash_cores": len(state.dash_cores),
                    "dash_cards": len(state.dash_cards),
                    "performance_memos": len(state._perf_memo),
                },
                "cache_deep_sizes": {
                    "schedules": deep_size(state.schedules),
                    "analyses": deep_size(state.analyses),
                    "cpms": deep_size(state.cpms),
                    "summaries": deep_size(state.summaries),
                    "dash_cores": deep_size(state.dash_cores),
                    "dash_cards": deep_size(state.dash_cards),
                    "performance_memos": deep_size(state._perf_memo),
                },
            }
        )

    capture("raw schedule loaded")
    state.analysis_for("large", schedule)
    capture("full analysis")
    state.summary_for("large", schedule)
    capture("summary")
    default_dashboard = client.get("/").content
    capture("dashboard")
    client.get("/performance")
    capture("performance")
    analysis_payload = client.get("/api/analysis/large").content
    capture("serialized analysis response released")

    # Exercise many target epochs. analyses/cpms are bounded, but dash_* and summaries are plain
    # epoch-keyed dictionaries. Use 60 valid targets sampled across the file.
    valid_uids = [
        task.unique_id for task in schedule.tasks if not task.is_summary and task.is_active
    ]
    targets = [
        valid_uids[round(index * (len(valid_uids) - 1) / 59)]
        for index in range(60)
    ]
    epoch_times: list[float] = []
    for uid in targets:
        state.set_target(uid)
        started = time.perf_counter()
        client.get("/")
        epoch_times.append((time.perf_counter() - started) * 1000)
    capture("after 60 distinct target dashboard epochs")
    state.set_target(None)
    with count_cpm_calls() as counts:
        restored_dashboard = client.get("/").content
    capture("target cleared")

    # Same-key replacement must miss the identity guard and move a deterministic result.
    syn = synthetic_schedule(50, name="stale-test")
    stale = SessionState(schedules={"same": syn}, dcma_acumen_parity=False)
    first = stale.analysis_for("same", syn)
    tasks = list(syn.tasks)
    tasks[0] = tasks[0].model_copy(update={"duration_minutes": 540})
    replaced = syn.model_copy(update={"tasks": tuple(tasks)})
    stale.schedules["same"] = replaced
    second = stale.analysis_for("same", replaced)

    # In-flight compute cannot repopulate a wiped state.
    wipe_state = SessionState(schedules={"wipe": synthetic_schedule(100, name="wipe")})
    wipe_client = TestClient(create_app(wipe_state))
    original_analysis = state_module._compute_analysis
    started_event = threading.Event()
    continue_event = threading.Event()
    worker_error: list[str] = []

    def delayed(*args: Any, **kwargs: Any) -> Any:
        started_event.set()
        if not continue_event.wait(timeout=10):
            raise RuntimeError("wipe probe timed out")
        return original_analysis(*args, **kwargs)

    def worker() -> None:
        try:
            wipe_state.analysis_for("wipe", wipe_state.schedules["wipe"])
        except Exception as exc:
            worker_error.append(f"{type(exc).__name__}: {exc}")

    state_module._compute_analysis = delayed
    thread = threading.Thread(target=worker)
    thread.start()
    started_event.wait(timeout=10)
    wipe_response = wipe_client.post("/session/wipe", follow_redirects=False)
    continue_event.set()
    thread.join(timeout=20)
    state_module._compute_analysis = original_analysis

    # Independent engine-version coverage check and a virtual mutation of cpm.py.
    base = Path(sys.modules["schedule_forensics"].__file__).resolve().parent
    source_files = [
        path
        for sub in ("importers", "model", "engine")
        for path in sorted((base / sub).rglob("*.py"))
    ]

    def independent_engine_digest(mutated: Path | None = None) -> str:
        digest = hashlib.sha256()
        for path in source_files:
            digest.update(path.relative_to(base).as_posix().encode())
            raw = path.read_bytes()
            if path == mutated:
                raw += b"\n# virtual benchmark mutation\n"
            digest.update(hashlib.sha256(raw).digest())
        return digest.hexdigest()[:16]

    cpm_path = base / "engine/cpm.py"
    return {
        "retention_stages": stages,
        "analysis_response_bytes": len(analysis_payload),
        "analysis_response_sha256": sha_bytes(analysis_payload),
        "target_epoch_latency_ms": summary(epoch_times),
        "target_epoch_counts": {
            "targets": len(targets),
            "unique_targets": len(set(targets)),
            "analyses": len(state.analyses),
            "cpms": len(state.cpms),
            "summaries": len(state.summaries),
            "dash_cores": len(state.dash_cores),
            "dash_cards": len(state.dash_cards),
        },
        "reversible_scope": {
            "dashboard_before_sha256": sha_bytes(default_dashboard),
            "dashboard_after_sha256": sha_bytes(restored_dashboard),
            "identical": default_dashboard == restored_dashboard,
            "cpm_calls_on_restore": counts["compute_cpm"],
            "full_analysis_calls_on_restore": counts["full_analysis"],
        },
        "same_key_replacement": {
            "object_identity_changed": syn is not replaced,
            "first_project_finish": first.cpm.project_finish,
            "second_project_finish": second.cpm.project_finish,
            "moved": first.cpm.project_finish != second.cpm.project_finish,
        },
        "wipe_in_flight": {
            "route_status": wipe_response.status_code,
            "worker_alive": thread.is_alive(),
            "worker_errors": worker_error,
            "wipe_generation": wipe_state.wipe_gen,
            "schedules_after": len(wipe_state.schedules),
            "analyses_after": len(wipe_state.analyses),
            "cpms_after": len(wipe_state.cpms),
            "dash_cores_after": len(wipe_state.dash_cores),
            "dash_cards_after": len(wipe_state.dash_cards),
        },
        "engine_version": {
            "reported": engine_version(),
            "independent": independent_engine_digest(),
            "source_file_count": len(source_files),
            "virtual_cpm_mutation": independent_engine_digest(cpm_path),
            "changes_on_cpm_mutation": independent_engine_digest(cpm_path)
            != independent_engine_digest(),
        },
    }


def environment(java: str, playwright_root: Path) -> dict[str, Any]:
    dependencies = {}
    for name in (
        "fastapi",
        "starlette",
        "pydantic",
        "httpx",
        "openpyxl",
        "playwright",
        "psutil",
    ):
        try:
            from importlib.metadata import version

            dependencies[name] = version(name)
        except Exception as exc:
            dependencies[name] = f"unavailable: {exc}"
    try:
        import psutil

        memory = asdict(psutil.virtual_memory()) if is_dataclass(psutil.virtual_memory()) else str(
            psutil.virtual_memory()
        )
    except Exception as exc:
        memory = f"unavailable: {type(exc).__name__}: {exc}"
    java_result = subprocess.run(
        [java, "-version"], capture_output=True, text=True, env=os.environ.copy()
    )
    browser_candidates = list(playwright_root.rglob("chrome")) + list(
        playwright_root.rglob("chromium")
    )
    return {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor() or None,
        "logical_cpus": os.cpu_count(),
        "python": sys.version,
        "executable": sys.executable,
        "java_command": java,
        "java_returncode": java_result.returncode,
        "java_version": (java_result.stderr or java_result.stdout).strip(),
        "dependencies": dependencies,
        "memory": memory,
        "maxrss_units": "KiB on Linux",
        "browser": {
            "playwright_root": str(playwright_root),
            "executables": [str(path) for path in browser_candidates],
            "status": (
                "available"
                if browser_candidates
                else "environment-blocked: Chromium download failed; no executable present"
            ),
            "heap_layout_paint_fcp_tti_listeners_detached_nodes": "unavailable",
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pipeline-worker", type=Path)
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--large-xml", type=Path)
    parser.add_argument("--mpp", type=Path)
    parser.add_argument("--java")
    parser.add_argument("--java-classes", type=Path)
    parser.add_argument("--direct-classpath")
    parser.add_argument("--playwright-root", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.pipeline_worker:
        print(json.dumps(pipeline_profile(args.pipeline_worker)))
        return 0
    required = (
        args.repo,
        args.large_xml,
        args.mpp,
        args.java,
        args.java_classes,
        args.direct_classpath,
        args.playwright_root,
        args.output,
    )
    if any(value is None for value in required):
        parser.error("full mode requires repository, source, Java, browser, and output arguments")
    assert args.repo and args.large_xml and args.mpp and args.java
    assert args.java_classes and args.direct_classpath and args.playwright_root and args.output
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temp = args.output.parent / "perf-cache"
    temp.mkdir(parents=True, exist_ok=True)

    logging.getLogger("schedule_forensics").setLevel(logging.ERROR)
    results: dict[str, Any] = {"environment": environment(args.java, args.playwright_root)}

    def checkpoint() -> None:
        args.output.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")

    print("P1 pipeline", flush=True)
    results["P1"] = p1_pipeline(args.large_xml)
    checkpoint()
    print("P2/P6 retention", flush=True)
    schedule = parse_mspdi(args.large_xml)
    results["P2_P6"] = retention_and_cache_multiplication(schedule)
    checkpoint()
    print("P3 uploads", flush=True)
    results["P3_uploads"] = benchmark_uploads(args.large_xml, temp)
    checkpoint()
    print("P3 MPP", flush=True)
    results["P3_mpp"] = benchmark_mpp(
        args.repo,
        args.java,
        args.java_classes,
        args.direct_classpath,
        args.mpp,
        temp,
    )
    checkpoint()
    print("P4/P5 routes", flush=True)
    results["P4_P5"] = route_benchmarks(schedule)
    checkpoint()
    print("scaling", flush=True)
    results["scaling"] = scaling_benchmarks()
    results["environment_dependent"] = True
    checkpoint()
    payload = json.dumps(results, indent=2, default=str)
    args.output.write_text(payload, encoding="utf-8")
    print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
