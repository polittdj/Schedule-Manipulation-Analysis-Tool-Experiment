#!/usr/bin/env python3
"""Independent falsification probes for H1-H6.

The script imports the reviewed package read-only but constructs its own fixtures and oracles.
It writes all evidence outside the reviewed tree.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import statistics
from dataclasses import asdict
from enum import Enum
from pathlib import Path
from typing import Any
from urllib.parse import quote

from fastapi.testclient import TestClient

from schedule_forensics.engine.cpm import (
    CPMError,
    compute_cpm,
    datetime_to_offset,
    offset_to_datetime,
)
from schedule_forensics.engine.driving_slack import _whole_days
from schedule_forensics.engine.forecast import compute_finish_forecasts
from schedule_forensics.engine.msp_filters import _parse_duration_literal, select
from schedule_forensics.engine.sra import (
    SRAConfig,
    _ml_minutes,
    compute_sra_ssi,
    stored_finish_correction,
)
from schedule_forensics.engine.summary import compute_summary
from schedule_forensics.importers.mspdi import parse_mspdi
from schedule_forensics.model.calendar import Calendar
from schedule_forensics.model.relationship import Relationship
from schedule_forensics.model.saved_view import Criterion, Operand, SavedFilter
from schedule_forensics.model.schedule import Schedule
from schedule_forensics.model.task import Task
from schedule_forensics.web.app import (
    _reconcile_magnitudes,
    _risk_events,
    _schedule_risks,
    create_app,
)
from schedule_forensics.web.state import SessionState


def stamp(value: Any) -> Any:
    if isinstance(value, (dt.date, dt.datetime)):
        return value.isoformat()
    if isinstance(value, dt.timedelta):
        return value.total_seconds()
    if isinstance(value, Enum):
        return value.value
    if hasattr(value, "model_dump"):
        return stamp(value.model_dump())
    if hasattr(value, "__dataclass_fields__"):
        return {key: stamp(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): stamp(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [stamp(item) for item in value]
    return value


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def simple_schedule(*, saved_filters: tuple[SavedFilter, ...] = ()) -> Schedule:
    start = dt.datetime(2026, 1, 5, 8)
    return Schedule(
        name="independent-fixture",
        source_file="independent-fixture.json",
        project_start=start,
        project_finish=dt.datetime(2026, 1, 7, 17),
        status_date=dt.datetime(2026, 1, 6, 17),
        calendar=Calendar(day_segments=((480, 720), (780, 1020))),
        tasks=(
            Task(
                unique_id=1,
                name="One day",
                duration_minutes=480,
                remaining_duration_minutes=240,
                start=start,
                finish=dt.datetime(2026, 1, 5, 17),
                percent_complete=50,
            ),
            Task(
                unique_id=2,
                name="Two days",
                duration_minutes=960,
                remaining_duration_minutes=960,
                start=dt.datetime(2026, 1, 6, 8),
                finish=dt.datetime(2026, 1, 7, 17),
            ),
        ),
        relationships=(Relationship(predecessor_id=1, successor_id=2),),
        saved_filters=saved_filters,
    )


def progressed_chain() -> Schedule:
    start = dt.datetime(2026, 1, 5, 8)
    focus_finish = dt.datetime(2026, 1, 30, 17)
    return Schedule(
        name="progressed-fs-chain",
        source_file="independent-progressed-chain.json",
        project_start=start,
        project_finish=focus_finish,
        status_date=dt.datetime(2026, 1, 20, 8),
        calendar=Calendar(),
        tasks=(
            Task(
                unique_id=1,
                name="Completed",
                duration_minutes=480,
                remaining_duration_minutes=0,
                percent_complete=100,
                start=start,
                finish=dt.datetime(2026, 1, 5, 17),
                actual_start=start,
                actual_finish=dt.datetime(2026, 1, 5, 17),
            ),
            Task(
                unique_id=2,
                name="In progress",
                duration_minutes=2400,
                remaining_duration_minutes=480,
                percent_complete=80,
                start=dt.datetime(2026, 1, 6, 8),
                finish=dt.datetime(2026, 1, 21, 17),
                actual_start=dt.datetime(2026, 1, 6, 8),
            ),
            Task(
                unique_id=3,
                name="Focus milestone",
                duration_minutes=0,
                remaining_duration_minutes=0,
                percent_complete=0,
                is_milestone=True,
                start=focus_finish,
                finish=focus_finish,
            ),
        ),
        relationships=(
            Relationship(predecessor_id=1, successor_id=2),
            Relationship(predecessor_id=2, successor_id=3),
        ),
    )


def h1(large_xml: Path) -> dict[str, Any]:
    schedule = parse_mspdi(large_xml)
    focus_uid = 152
    focus = schedule.tasks_by_id[focus_uid]
    non_summary = [task for task in schedule.tasks if not task.is_summary and task.is_active]
    full = {task.unique_id: task.duration_minutes for task in non_summary}
    remaining = {
        task.unique_id: (
            task.remaining_duration_minutes
            if task.remaining_duration_minutes is not None
            else task.duration_minutes
        )
        for task in non_summary
    }
    ml = {task.unique_id: _ml_minutes(task) for task in non_summary}
    ordinary = compute_cpm(schedule)
    full_result = compute_cpm(schedule, duration_overrides=full)
    remaining_result = compute_cpm(schedule, duration_overrides=remaining)
    ml_result = compute_cpm(schedule, duration_overrides=ml)
    offsets = {
        "ordinary": ordinary.timing(focus_uid).early_finish,
        "all_full": full_result.timing(focus_uid).early_finish,
        "all_remaining": remaining_result.timing(focus_uid).early_finish,
        "exact_ml": ml_result.timing(focus_uid).early_finish,
    }
    raw_dates = {
        key: offset_to_datetime(schedule.project_start, value, schedule.calendar)
        for key, value in offsets.items()
    }
    corrections = {
        key: stored_finish_correction(schedule, focus_uid, value)
        for key, value in offsets.items()
    }
    cfg = SRAConfig(iterations=5, target_uid=focus_uid, use_risk_register=False)
    risk_free = compute_sra_ssi(schedule, config=cfg)
    point_mass = compute_sra_ssi(
        schedule,
        config=cfg,
        three_point={uid: (value, value, value) for uid, value in ml.items()},
    )

    chain = progressed_chain()
    chain_tasks = [task for task in chain.tasks if not task.is_summary]
    chain_ml = {task.unique_id: _ml_minutes(task) for task in chain_tasks}
    chain_ordinary = compute_cpm(chain).timing(3).early_finish
    chain_ml_finish = compute_cpm(chain, duration_overrides=chain_ml).timing(3).early_finish
    chain_anchor = chain.tasks_by_id[3].finish
    assert chain_anchor is not None
    chain_corrections = {
        "ordinary": stored_finish_correction(chain, 3, chain_ordinary),
        "ml": stored_finish_correction(chain, 3, chain_ml_finish),
    }
    corrected = {}
    for key, finish in (("ordinary", chain_ordinary), ("ml", chain_ml_finish)):
        raw = offset_to_datetime(chain.project_start, finish, chain.calendar)
        corrected[key] = {
            "offset": finish,
            "raw": raw,
            "correction": chain_corrections[key],
            "corrected": raw + chain_corrections[key],
        }
    ml_raw_next = offset_to_datetime(chain.project_start, chain_ml_finish + 480, chain.calendar)
    corrected["spacing_check"] = {
        "naive_delta_seconds": (
            ml_raw_next - offset_to_datetime(chain.project_start, chain_ml_finish, chain.calendar)
        ).total_seconds(),
        "corrected_delta_seconds": (
            (ml_raw_next + chain_corrections["ml"])
            - (
                offset_to_datetime(chain.project_start, chain_ml_finish, chain.calendar)
                + chain_corrections["ml"]
            )
        ).total_seconds(),
    }

    return {
        "source": {
            "path": str(large_xml),
            "sha256": sha256(large_xml),
            "name": schedule.name,
            "project_title": schedule.project_title,
            "source_file": schedule.source_file,
            "task_count": len(schedule.tasks),
            "non_summary_active_count": len(non_summary),
            "calendar": stamp(schedule.calendar),
            "status_date": schedule.status_date,
            "project_start": schedule.project_start,
            "project_finish": schedule.project_finish,
            "focus_uid": focus_uid,
            "focus_name": focus.name,
            "focus_duration": focus.duration_minutes,
            "focus_remaining_duration": focus.remaining_duration_minutes,
            "focus_finish": focus.finish,
            "focus_stored_critical": focus.stored_is_critical,
        },
        "duration_map_differences": {
            "ml_vs_full_count": sum(ml[uid] != full[uid] for uid in ml),
            "remaining_vs_full_count": sum(remaining[uid] != full[uid] for uid in ml),
            "completed_count": sum(task.percent_complete >= 100 for task in non_summary),
            "in_progress_count": sum(0 < task.percent_complete < 100 for task in non_summary),
        },
        "offsets": offsets,
        "raw_dates": raw_dates,
        "corrections_seconds": {
            key: value.total_seconds() for key, value in corrections.items()
        },
        "ml_minus_ordinary": offsets["exact_ml"] - offsets["ordinary"],
        "ml_minus_ordinary_working_days": (
            offsets["exact_ml"] - offsets["ordinary"]
        )
        / schedule.calendar.working_minutes_per_day,
        "risk_free": {
            "deterministic": risk_free.deterministic_finish,
            "p10": risk_free.p10,
            "p50": risk_free.p50,
            "p80": risk_free.p80,
            "p90": risk_free.p90,
            "deterministic_date": risk_free.deterministic_finish_date,
        },
        "point_mass": {
            "deterministic": point_mass.deterministic_finish,
            "p10": point_mass.p10,
            "p50": point_mass.p50,
            "p80": point_mass.p80,
            "p90": point_mass.p90,
            "deterministic_date": point_mass.deterministic_finish_date,
        },
        "minimal_progressed_chain": corrected,
    }


def _valid_date(calendar: Calendar, value: dt.datetime) -> bool:
    return calendar.is_working_day(value.date())


def h2(reference_roots: list[Path], repo: Path, large_xml: Path) -> dict[str, Any]:
    starts = [
        dt.datetime(2026, 1, 9, hour // 60, hour % 60)
        for hour in range(0, 24 * 60)
    ]  # every minute of a Friday
    calendar_specs = {
        "8h_mf": Calendar(working_minutes_per_day=480),
        "10h_mf": Calendar(working_minutes_per_day=600),
        "12h_mf": Calendar(working_minutes_per_day=720),
        "20h_mf": Calendar(working_minutes_per_day=1200),
        "24h_mf": Calendar(working_minutes_per_day=1440),
        "8h_tue_sat": Calendar(working_minutes_per_day=480, work_weekdays=(1, 2, 3, 4, 5)),
        "8h_all_days": Calendar(working_minutes_per_day=480, work_weekdays=tuple(range(7))),
        "8h_holiday": Calendar(
            working_minutes_per_day=480, holidays=(dt.date(2026, 1, 12),)
        ),
    }
    sweeps: dict[str, Any] = {}
    examples: list[dict[str, Any]] = []
    for name, calendar in calendar_specs.items():
        per_day = calendar.working_minutes_per_day
        offsets = sorted({0, 1, per_day - 1, per_day, per_day + 1, 2 * per_day - 1, 2 * per_day, 2 * per_day + 1})
        nonworking = 0
        mismatches = 0
        total = 0
        for start in starts:
            for offset in offsets:
                value = offset_to_datetime(start, offset, calendar)
                roundtrip = datetime_to_offset(start, value, calendar)
                invalid = not _valid_date(calendar, value)
                mismatch = roundtrip != offset
                nonworking += invalid
                mismatches += mismatch
                total += 1
                if (invalid or mismatch) and len(examples) < 25:
                    examples.append(
                        {
                            "calendar": name,
                            "start": start,
                            "offset": offset,
                            "result": value,
                            "result_working_date": not invalid,
                            "roundtrip": roundtrip,
                        }
                    )
        sweeps[name] = {
            "start_minutes_tested": len(starts),
            "offsets": offsets,
            "cases": total,
            "nonworking_date_results": nonworking,
            "roundtrip_mismatches": mismatches,
        }

    explicit = []
    for start, calendar, offsets in (
        (
            dt.datetime(2026, 1, 10, 8),  # non-working Saturday start
            Calendar(),
            (0, 1, 479, 480, 481),
        ),
        (
            dt.datetime(2026, 1, 12, 8),  # Monday holiday start
            Calendar(holidays=(dt.date(2026, 1, 12),)),
            (0, 1, 479, 480, 481),
        ),
        (
            dt.datetime(2026, 1, 9, 16),  # prior report boundary
            Calendar(),
            (479, 480, 481),
        ),
    ):
        for offset in offsets:
            result = offset_to_datetime(start, offset, calendar)
            explicit.append(
                {
                    "start": start,
                    "calendar": stamp(calendar),
                    "offset": offset,
                    "result": result,
                    "working_date": calendar.is_working_day(result.date()),
                    "roundtrip": datetime_to_offset(start, result, calendar),
                }
            )

    # Caller reachability on real MSPDI files: parse every unique XML payload whose root is Project,
    # solve it where possible, and test the returned project-finish timestamp.
    candidates = [large_xml]
    for root in [repo, *reference_roots]:
        candidates.extend(root.rglob("*.xml"))
    seen: set[str] = set()
    real: list[dict[str, Any]] = []
    for path in candidates:
        file_hash = sha256(path)
        if file_hash in seen:
            continue
        seen.add(file_hash)
        try:
            schedule = parse_mspdi(path)
        except Exception:
            continue
        try:
            cpm = compute_cpm(schedule)
        except CPMError as exc:
            real.append({"path": str(path), "sha256": file_hash, "cpm_error": str(exc)})
            continue
        finish = offset_to_datetime(schedule.project_start, cpm.project_finish, schedule.calendar)
        real.append(
            {
                "path": str(path),
                "sha256": file_hash,
                "tasks": len(schedule.tasks),
                "project_start": schedule.project_start,
                "minutes_per_day": schedule.calendar.working_minutes_per_day,
                "work_weekdays": schedule.calendar.work_weekdays,
                "cpm_finish_offset": cpm.project_finish,
                "cpm_finish": finish,
                "finish_on_working_date": schedule.calendar.is_working_day(finish.date()),
                "roundtrip": datetime_to_offset(
                    schedule.project_start, finish, schedule.calendar
                ),
                "roundtrip_matches": datetime_to_offset(
                    schedule.project_start, finish, schedule.calendar
                )
                == cpm.project_finish,
            }
        )
    late_start = dt.datetime(2026, 1, 9, 16)
    late_schedule = Schedule(
        name="late-start",
        source_file="late-start.json",
        project_start=late_start,
        calendar=Calendar(),
        tasks=(Task(unique_id=1, name="Eight hours", duration_minutes=480),),
    )
    late_cpm = compute_cpm(late_schedule)
    late_finish = offset_to_datetime(
        late_schedule.project_start, late_cpm.project_finish, late_schedule.calendar
    )
    late_summary = compute_summary(late_schedule)
    late_state = SessionState(schedules={"late": late_schedule})
    late_page = TestClient(create_app(late_state)).get("/analysis/late")

    return {
        "sweeps": sweeps,
        "first_failures": examples,
        "explicit_boundaries": explicit,
        "real_mspdi": {
            "unique_project_files": len(real),
            "invalid_finish_dates": sum(
                row.get("finish_on_working_date") is False for row in real
            ),
            "roundtrip_mismatches": sum(row.get("roundtrip_matches") is False for row in real),
            "cases": real,
        },
        "supported_json_shape_reachability": {
            "project_start": late_start,
            "cpm_finish_offset": late_cpm.project_finish,
            "converted_finish": late_finish,
            "finish_on_working_date": late_schedule.calendar.is_working_day(late_finish.date()),
            "roundtrip": datetime_to_offset(
                late_schedule.project_start, late_finish, late_schedule.calendar
            ),
            "summary_finish": late_summary.finish_iso,
            "analysis_status": late_page.status_code,
            "analysis_displays_saturday": "01/10/2026" in late_page.text
            or "2026-01-10" in late_page.text,
        },
    }


H3_VALUES = [
    "",
    "   ",
    "typo",
    "12abc",
    "NaN",
    "Infinity",
    "-Infinity",
    "1,5",
    "-2.5",
    "0",
    "1e2",
    "1e309",
    "9" * 400,
]


def h3() -> dict[str, Any]:
    helper = []
    for days in H3_VALUES:
        for pct in ("", "25"):
            try:
                result: Any = _reconcile_magnitudes(days, pct, False, False, 10)
                error = None
            except Exception as exc:
                result = None
                error = f"{type(exc).__name__}: {exc}"
            helper.append({"days": days, "pct": pct, "result": result, "error": error})

    route = []
    for days in H3_VALUES:
        state = SessionState(schedules={"fixture": simple_schedule()}, sra_file="fixture")
        client = TestClient(create_app(state))
        response = client.post(
            "/sra/risk-register",
            data={
                "action": "add",
                "name": "Boundary risk",
                "prob": "50",
                "affected": "1",
                "impact_days": days,
                "impact_pct": "25",
            },
            follow_redirects=False,
        )
        risk = state.sra_risks[0] if state.sra_risks else None
        route.append(
            {
                "days": days,
                "status": response.status_code,
                "risk": stamp(risk) if risk else None,
                "ssi_model": stamp(_schedule_risks(state)),
                "legacy_model": stamp(_risk_events(state)),
            }
        )

    # Persist the malformed-direct-POST state and restore it into a fresh session.
    state = SessionState(schedules={"fixture": simple_schedule()}, sra_file="fixture")
    client = TestClient(create_app(state))
    client.post(
        "/sra/risk-register",
        data={
            "name": "Persisted malformed",
            "prob": "50",
            "affected": "1",
            "impact_days": "typo",
            "impact_pct": "25",
        },
    )
    saved = client.get("/sra/ssi/save")
    restored = SessionState(schedules={"fixture": simple_schedule()}, sra_file="fixture")
    restored_client = TestClient(create_app(restored))
    load = restored_client.post(
        "/sra/ssi/load",
        files={"setup": ("sra-ssi-setup.json", saved.content, "application/json")},
        follow_redirects=False,
    )
    html = client.get("/sra").text
    return {
        "helper": helper,
        "post_route": route,
        "save_reload": {
            "save_status": saved.status_code,
            "saved_sha256": hashlib.sha256(saved.content).hexdigest(),
            "load_status": load.status_code,
            "before": stamp(state.sra_risks),
            "after": stamp(restored.sra_risks),
        },
        "html_number_inputs": {
            "days": 'name="impact_days"' in html or "name=impact_days" in html,
            "pct": 'name="impact_pct"' in html or "name=impact_pct" in html,
            "type_number_occurrences": html.count("type=number"),
        },
        "real_browser": "environment-blocked: Playwright Chromium download unavailable",
    }


def duration_filter(literal: str) -> SavedFilter:
    return SavedFilter(
        name=f"Duration equals {literal}",
        criteria=Criterion(
            operator="EQUALS",
            field="Duration",
            field_enum="DURATION",
            operands=(Operand(kind="literal", text=literal, value_type="Duration"),),
        ),
    )


def h4() -> dict[str, Any]:
    literals = [
        "2 d",
        "2 ed",
        "2 xyz",
        "2",
        "2 h",
        "bad",
        "2 D",
        "  2.5   days ",
        "2,5 d",
        "-2 d",
        ".5d",
        "2 emin",
        "2 ewks",
        "2 fortnight",
    ]
    parsed = {literal: _parse_duration_literal(literal) for literal in literals}
    populations = {}
    for literal in literals:
        filt = duration_filter(literal)
        populations[literal] = select(simple_schedule(saved_filters=(filt,)), filt)

    filt = duration_filter("2 ed")
    schedule = simple_schedule(saved_filters=(filt,))
    state = SessionState(schedules={"fixture": schedule})
    client = TestClient(create_app(state))
    response = client.get("/groups", params={"saved_filter": filt.name})
    scoped = state.scope(schedule)
    axis_schedule = Schedule(
        name="elapsed-duration-filter-differential",
        source_file="elapsed-duration-filter-differential.json",
        project_start=dt.datetime(2026, 1, 5, 8),
        calendar=Calendar(),
        tasks=(
            Task(
                unique_id=10,
                name="ordinary-two-days",
                duration_minutes=960,
            ),
            Task(
                unique_id=20,
                name="elapsed-two-days",
                duration_minutes=2880,
                duration_is_elapsed=True,
            ),
            Task(
                unique_id=30,
                name="ordinary-six-days",
                duration_minutes=2880,
            ),
        ),
        saved_filters=(filt,),
    )
    return {
        "literal_results": parsed,
        "selected_uids": populations,
        "elapsed_axis_differential": {
            "python_selected_uids": select(axis_schedule, filt),
            "task_axes": [
                {
                    "uid": task.unique_id,
                    "name": task.name,
                    "duration_minutes": task.duration_minutes,
                    "duration_is_elapsed": task.duration_is_elapsed,
                }
                for task in axis_schedule.tasks
            ],
            "mpxj_oracle_artifact": "mpxj-filter-duration-probe.txt",
        },
        "served_saved_filter": {
            "status": response.status_code,
            "active_name": state.active_saved_filter.name if state.active_saved_filter else None,
            "scoped_uids": [task.unique_id for task in scoped.tasks],
            "page_mentions_filter": filt.display_name in response.text,
        },
    }


def h5() -> dict[str, Any]:
    points = [-1441, -1440, -1201, -1200, -601, -600, -481, -480, -479, -1, 0, 1, 479, 480, 481, 599, 600, 601, 1199, 1200, 1201, 1439, 1440, 1441]
    return {
        str(per_day): [
            {
                "minutes": value,
                "whole_days": _whole_days(value, per_day),
                "truncate_toward_zero": math.trunc(value / per_day),
                "classification_with_5_10": (
                    "DRIVING"
                    if _whole_days(value, per_day) <= 0
                    else "SECONDARY"
                    if _whole_days(value, per_day) <= 5
                    else "TERTIARY"
                    if _whole_days(value, per_day) <= 10
                    else "BEYOND"
                ),
            }
            for value in points
        ]
        for per_day in (480, 600, 720, 1200, 1440)
    }


def h6(tp4_xml: Path) -> dict[str, Any]:
    schedule = parse_mspdi(tp4_xml)
    cpm = compute_cpm(schedule)
    cpm_finish = offset_to_datetime(
        schedule.project_start, cpm.project_finish, schedule.calendar
    ).date()
    stored_finish = max(
        task.finish for task in schedule.tasks if task.finish is not None
    ).date()
    forecasts = compute_finish_forecasts(schedule, cpm)
    state = SessionState(schedules={"tp4": schedule})
    client = TestClient(create_app(state))
    forecast_page = client.get("/forecast")

    chain = progressed_chain()
    chain_cpm = compute_cpm(chain)
    chain_cpm_finish = offset_to_datetime(
        chain.project_start, chain_cpm.project_finish, chain.calendar
    )
    # Independent status-aware lower bound for the to-go part of this simple FS chain:
    # completed actuals are historical; the remaining 480-minute in-progress task cannot resume
    # before the status date; the downstream milestone follows it.
    status_aware = offset_to_datetime(chain.status_date, 480, chain.calendar)  # type: ignore[arg-type]
    return {
        "tp4": {
            "path": str(tp4_xml),
            "sha256": sha256(tp4_xml),
            "project_start": schedule.project_start,
            "status_date": schedule.status_date,
            "raw_project_finish": schedule.project_finish,
            "raw_latest_task_finish": stored_finish,
            "cpm_offset": cpm.project_finish,
            "cpm_finish": cpm_finish,
            "gap_calendar_days": (stored_finish - cpm_finish).days,
            "forecasts": stamp(forecasts.forecasts),
            "forecast_page_status": forecast_page.status_code,
            "page_has_pure_logic_label": "Schedule logic (CPM)" in forecast_page.text,
            "page_has_stored_label": "As-scheduled (stored dates)" in forecast_page.text,
            "page_has_cpm_date": cpm_finish.strftime("%m/%d/%Y") in forecast_page.text
            or cpm_finish.isoformat() in forecast_page.text,
            "page_has_stored_date": stored_finish.strftime("%m/%d/%Y") in forecast_page.text
            or stored_finish.isoformat() in forecast_page.text,
        },
        "minimal_progressed_chain": {
            "pure_logic": chain_cpm_finish,
            "stored_focus_finish": chain.tasks_by_id[3].finish,
            "independent_status_aware_finish": status_aware,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--large-xml", type=Path, required=True)
    parser.add_argument("--reference", type=Path, action="append", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    results: dict[str, Any] = {}
    print("H1", flush=True)
    results["H1"] = h1(args.large_xml)
    print("H2", flush=True)
    results["H2"] = h2(args.reference, args.repo, args.large_xml)
    print("H3", flush=True)
    results["H3"] = h3()
    print("H4", flush=True)
    results["H4"] = h4()
    print("H5", flush=True)
    results["H5"] = h5()
    print("H6", flush=True)
    results["H6"] = h6(args.repo / "tests/fixtures/test_projects/TP4_DataCenter_v5.xml")
    payload = json.dumps(stamp(results), indent=2, allow_nan=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(payload, encoding="utf-8")
    print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
