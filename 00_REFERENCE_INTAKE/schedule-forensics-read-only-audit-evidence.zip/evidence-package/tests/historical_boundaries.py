#!/usr/bin/env python3
"""Fresh boundary fixtures for allegations reported as fixed at the reviewed commit.

This is deliberately separate from the repository's regression tests. Expectations are derived
from model contracts, elementary arithmetic, and explicit input distinctions (missing vs zero).
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
from pathlib import Path
from typing import Any, Callable

from schedule_forensics.engine.cpm import compute_cpm
from schedule_forensics.engine.manipulation import detect_manipulation
from schedule_forensics.engine.resources import compute_resource_loading
from schedule_forensics.engine.sra import (
    RiskFactorTable,
    SRAConfig,
    compute_sra_ssi,
    factor_to_bc_wc,
)
from schedule_forensics.importers.json_schedule import parse_json_text
from schedule_forensics.importers.mspdi import parse_mspdi_text
from schedule_forensics.importers.xer import parse_xer_text
from schedule_forensics.model.assignment import Assignment
from schedule_forensics.model.relationship import Relationship
from schedule_forensics.model.resource import Resource
from schedule_forensics.model.schedule import Schedule
from schedule_forensics.model.task import Task


START = dt.datetime(2026, 2, 2, 8)


class Capture(logging.Handler):
    def __init__(self) -> None:
        super().__init__(logging.WARNING)
        self.messages: list[str] = []

    def emit(self, record: logging.LogRecord) -> None:
        self.messages.append(record.getMessage())


def capture_warnings(logger_name: str, operation: Callable[[], Any]) -> tuple[Any, list[str]]:
    logger = logging.getLogger(logger_name)
    handler = Capture()
    previous = logger.level
    logger.setLevel(logging.WARNING)
    logger.addHandler(handler)
    try:
        return operation(), handler.messages
    finally:
        logger.removeHandler(handler)
        logger.setLevel(previous)


def one_task_schedule(task: Task, *, name: str) -> Schedule:
    return Schedule(
        name=name,
        source_file=f"{name}.json",
        project_start=START,
        tasks=(task,),
    )


def sra_boundaries() -> dict[str, Any]:
    table = RiskFactorTable()
    factor_rows = []
    for factor in range(0, 6):
        actual = factor_to_bc_wc(1000, factor, table)
        expected = (
            (1000, 1000, 1000)
            if factor == 0
            else ((6 - factor) * 100, 1000, (10 + factor) * 100)
        )
        factor_rows.append(
            {
                "factor": factor,
                "actual": actual,
                "independent_expected": expected,
                "matches": actual == expected,
            }
        )

    complete = one_task_schedule(
        Task(
            unique_id=1,
            name="Recorded actual",
            duration_minutes=1000,
            remaining_duration_minutes=0,
            percent_complete=100,
            actual_start=START,
            actual_finish=START + dt.timedelta(days=2),
        ),
        name="completed-point-mass",
    )
    incomplete = one_task_schedule(
        Task(
            unique_id=1,
            name="Forecast work",
            duration_minutes=1000,
            remaining_duration_minutes=1000,
            percent_complete=0,
        ),
        name="incomplete-control",
    )
    wide = {1: (100, 1000, 1900)}
    completed_runs = [
        compute_sra_ssi(
            complete,
            config=SRAConfig(iterations=250, seed=seed, target_uid=1),
            three_point=wide,
        )
        for seed in (7, 91)
    ]
    control = compute_sra_ssi(
        incomplete,
        config=SRAConfig(iterations=250, seed=7, target_uid=1),
        three_point=wide,
    )
    completed = [
        {
            "seed": result.seed,
            "deterministic": result.deterministic_finish,
            "p10": result.p10,
            "p50": result.p50,
            "p80": result.p80,
            "p90": result.p90,
            "std_days": result.std_days,
            "cdf_points": len(result.cdf),
        }
        for result in completed_runs
    ]
    return {
        "best_case_formula": factor_rows,
        "completed_activity": completed,
        "incomplete_control_std_days": control.std_days,
        "best_case_formula_pass": all(row["matches"] for row in factor_rows),
        "completed_point_mass_pass": all(
            result.std_days == 0.0
            and result.p10 == result.deterministic_finish
            and result.p90 == result.deterministic_finish
            for result in completed_runs
        ),
        "incomplete_control_spreads": control.std_days > 0.0,
    }


def manipulation_boundaries() -> dict[str, Any]:
    prior_task = Task(
        unique_id=1,
        name="Cost-loaded activity",
        duration_minutes=960,
        cost=12000.0,
        actual_cost=5000.0,
        work_minutes=4800,
        actual_work_minutes=2400,
    )
    omitted_task = Task(unique_id=1, name="Cost-loaded activity", duration_minutes=960)
    rollback_task = Task(
        unique_id=1,
        name="Cost-loaded activity",
        duration_minutes=960,
        cost=9000.0,
        actual_cost=3000.0,
        work_minutes=2400,
        actual_work_minutes=1200,
    )
    added_task = Task(
        unique_id=1,
        name="Cost-loaded activity",
        duration_minutes=960,
        cost=12000.0,
        actual_cost=5000.0,
        work_minutes=4800,
        actual_work_minutes=2400,
    )
    absent = one_task_schedule(
        Task(unique_id=1, name="Cost-loaded activity", duration_minutes=960),
        name="prior-absent",
    )
    prior = one_task_schedule(prior_task, name="prior-costed")
    omitted = one_task_schedule(omitted_task, name="current-columns-omitted")
    rollback = one_task_schedule(rollback_task, name="current-real-rollback")
    added = one_task_schedule(added_task, name="current-new-columns")

    missing_ids = [finding.metric_id for finding in detect_manipulation(omitted, prior)]
    rollback_ids = [finding.metric_id for finding in detect_manipulation(rollback, prior)]
    newly_present_ids = [finding.metric_id for finding in detect_manipulation(added, absent)]
    return {
        "present_to_missing_metric_ids": missing_ids,
        "numeric_rollback_metric_ids": rollback_ids,
        "missing_to_present_metric_ids": newly_present_ids,
        "missing_is_not_zero_pass": not missing_ids and not newly_present_ids,
        "real_rollback_control_pass": {
            "MANIP_ACTUAL_COST_ERASED",
            "MANIP_ACTUAL_WORK_ERASED",
            "MANIP_COST_CHANGE",
            "MANIP_WORK_CHANGE",
        }.issubset(set(rollback_ids)),
    }


def resource_boundaries() -> dict[str, Any]:
    assignment = Assignment(resource_id=77, work_minutes=480, units=1.0)
    task = Task(
        unique_id=1,
        name="One staffed day",
        duration_minutes=480,
        resource_ids=(77,),
        resource_names=("Unavailable crew",),
        resource_assignments=(assignment,),
    )

    def load(max_units: float | None) -> Any:
        schedule = Schedule(
            name=f"capacity-{max_units}",
            source_file="capacity-boundary.json",
            project_start=START,
            tasks=(task,),
            resources=(
                Resource(unique_id=77, name="Unavailable crew", max_units=max_units),
            ),
        )
        return compute_resource_loading(
            schedule, compute_cpm(schedule), granularity="day"
        ).resources[0]

    zero = load(0.0)
    missing = load(None)
    return {
        "declared_zero": {
            "reported_max_units": zero.max_units,
            "periods": [
                {
                    "period": period.period,
                    "load": period.load_minutes,
                    "capacity": period.capacity_minutes,
                    "over_allocated": period.over_allocated,
                }
                for period in zero.series
            ],
            "over_allocated_periods": zero.over_allocated_periods,
        },
        "missing_control_max_units": missing.max_units,
        "zero_preserved_pass": zero.max_units == 0.0
        and all(period.capacity_minutes == 0.0 for period in zero.series),
        "zero_overallocation_pass": bool(zero.over_allocated_periods)
        and any(period.load_minutes > 0 and period.over_allocated for period in zero.series),
        "missing_defaults_to_one_pass": missing.max_units == 1.0,
    }


def json_boundaries() -> dict[str, Any]:
    def document(calendar_fields: str) -> str:
        return (
            '{"name":"calendar-boundary","project_start":"2026-02-02T08:00:00",'
            f'"calendars":[{{"name":"declared",{calendar_fields}}}],'
            '"tasks":[{"unique_id":1,"name":"A","duration_minutes":480}]}'
        )

    outcomes: dict[str, Any] = {}
    for name, fields in (
        ("zero_hours", '"hours_per_day":0'),
        ("empty_week", '"hours_per_day":8,"work_weekdays":[]'),
        ("absent_fields", '"uid":1'),
        ("explicit_nondefault", '"hours_per_day":10,"work_weekdays":[0,1,2,3]'),
    ):
        try:
            calendar = parse_json_text(document(fields)).calendar
            outcomes[name] = {
                "accepted": True,
                "minutes": calendar.working_minutes_per_day,
                "weekdays": calendar.work_weekdays,
            }
        except Exception as exc:
            outcomes[name] = {
                "accepted": False,
                "error_type": type(exc).__name__,
                "error": str(exc),
            }
    return {
        "outcomes": outcomes,
        "zero_hours_rejected_pass": not outcomes["zero_hours"]["accepted"],
        "empty_week_rejected_pass": not outcomes["empty_week"]["accepted"],
        "absent_defaults_pass": outcomes["absent_fields"].get("minutes") == 480
        and outcomes["absent_fields"].get("weekdays") == (0, 1, 2, 3, 4),
        "explicit_nondefault_pass": outcomes["explicit_nondefault"].get("minutes") == 600
        and outcomes["explicit_nondefault"].get("weekdays") == (0, 1, 2, 3),
    }


def importer_warning_boundaries() -> dict[str, Any]:
    mspdi = """<?xml version="1.0" encoding="UTF-8"?>
<Project xmlns="http://schemas.microsoft.com/project">
  <Name>Dangling calendar</Name>
  <StartDate>2026-02-02T08:00:00</StartDate>
  <CalendarUID>404</CalendarUID>
  <Calendars>
    <Calendar><UID>5</UID><Name>Ten hour source calendar</Name>
      <IsBaseCalendar>1</IsBaseCalendar>
      <WeekDays><WeekDay><DayType>2</DayType><DayWorking>1</DayWorking>
        <WorkingTimes><WorkingTime><FromTime>07:00:00</FromTime>
          <ToTime>17:00:00</ToTime></WorkingTime></WorkingTimes>
      </WeekDay></WeekDays>
    </Calendar>
  </Calendars>
  <Tasks><Task><UID>1</UID><ID>1</ID><Name>A</Name>
    <Duration>PT8H0M0S</Duration></Task></Tasks>
</Project>"""
    xer = """ERMHDR\t19.12\t2026-02-02\tProject\tadmin\tadmin\tUSD
%T\tPROJECT
%F\tproj_id\tclndr_id\tproj_short_name\tplan_start_date
%R\t1\t404\tDanglingCal\t2026-02-02 08:00
%T\tCALENDAR
%F\tclndr_id\tclndr_name\tday_hr_cnt\tdefault_flag\tclndr_data
%R\t5\tTenHour\t10\tN\t
%T\tTASK
%F\ttask_id\tproj_id\ttask_code\ttask_name\ttarget_drtn_hr_cnt
%R\t1\t1\tA100\tA\t8
%E
"""
    msp_schedule, msp_messages = capture_warnings(
        "schedule_forensics.importers.mspdi", lambda: parse_mspdi_text(mspdi)
    )
    xer_schedule, xer_messages = capture_warnings(
        "schedule_forensics.importers.xer", lambda: parse_xer_text(xer)
    )
    return {
        "mspdi": {
            "fallback_minutes": msp_schedule.calendar.working_minutes_per_day,
            "warnings": msp_messages,
            "pass": msp_schedule.calendar.working_minutes_per_day == 480
            and any("404" in message and "default" in message.lower() for message in msp_messages),
        },
        "xer": {
            "fallback_minutes": xer_schedule.calendar.working_minutes_per_day,
            "warnings": xer_messages,
            "pass": xer_schedule.calendar.working_minutes_per_day == 480
            and any("404" in message and "default" in message.lower() for message in xer_messages),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = {
        "ssi": sra_boundaries(),
        "manipulation": manipulation_boundaries(),
        "resources": resource_boundaries(),
        "json": json_boundaries(),
        "importer_warnings": importer_warning_boundaries(),
    }
    checks = {
        "ssi_best_case": results["ssi"]["best_case_formula_pass"],
        "ssi_completed_point_mass": results["ssi"]["completed_point_mass_pass"],
        "ssi_incomplete_control": results["ssi"]["incomplete_control_spreads"],
        "manipulation_missing_not_zero": results["manipulation"]["missing_is_not_zero_pass"],
        "manipulation_real_rollback": results["manipulation"]["real_rollback_control_pass"],
        "resource_zero_preserved": results["resources"]["zero_preserved_pass"],
        "resource_zero_overallocated": results["resources"]["zero_overallocation_pass"],
        "resource_missing_control": results["resources"]["missing_defaults_to_one_pass"],
        "json_zero_hours_rejected": results["json"]["zero_hours_rejected_pass"],
        "json_empty_week_rejected": results["json"]["empty_week_rejected_pass"],
        "json_absent_defaults": results["json"]["absent_defaults_pass"],
        "json_nondefault_control": results["json"]["explicit_nondefault_pass"],
        "mspdi_warning": results["importer_warnings"]["mspdi"]["pass"],
        "xer_warning": results["importer_warnings"]["xer"]["pass"],
    }
    payload = {"checks": checks, "all_pass": all(checks.values()), "results": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    print(json.dumps(payload, indent=2, default=str))
    return 0 if payload["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
