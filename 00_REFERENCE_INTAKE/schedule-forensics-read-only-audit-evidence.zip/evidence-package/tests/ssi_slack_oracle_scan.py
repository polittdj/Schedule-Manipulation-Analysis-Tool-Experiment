#!/usr/bin/env python3
"""Inventory SSI Directional Path workbooks for a negative sub-day slack oracle."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from openpyxl import load_workbook


SLACK_LITERAL = re.compile(
    r"^\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*(?:day|days)?\s*$",
    re.IGNORECASE,
)


def slack_number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        match = SLACK_LITERAL.match(value)
        return float(match.group(1)) if match else None
    return None


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    physical = sorted(
        {
            path
            for root in args.root
            for path in root.rglob("*.xlsx")
            if "directional_path_analysis" in path.name.lower()
        }
    )
    unique: dict[str, Path] = {}
    duplicates: dict[str, list[str]] = {}
    for path in physical:
        digest = sha256(path)
        unique.setdefault(digest, path)
        duplicates.setdefault(digest, []).append(str(path))

    records: list[dict[str, Any]] = []
    all_negative: list[dict[str, Any]] = []
    all_negative_subday: list[dict[str, Any]] = []
    errors: list[dict[str, str]] = []
    for digest, path in sorted(unique.items(), key=lambda item: str(item[1])):
        try:
            workbook = load_workbook(path, read_only=True, data_only=True)
            headers: list[dict[str, Any]] = []
            for sheet in workbook.worksheets:
                rows = list(sheet.iter_rows(values_only=True))
                for row_index, row in enumerate(rows, 1):
                    for column_index, value in enumerate(row, 1):
                        if not isinstance(value, str) or value.strip().lower() != "driving slack":
                            continue
                        numeric: list[dict[str, Any]] = []
                        for data_row_index in range(row_index, len(rows)):
                            data_row = rows[data_row_index]
                            if column_index > len(data_row):
                                continue
                            raw_candidate = data_row[column_index - 1]
                            candidate = slack_number(raw_candidate)
                            if candidate is None:
                                continue
                            item = {
                                "path": str(path),
                                "sha256": digest,
                                "sheet": sheet.title,
                                "header": value,
                                "row": data_row_index + 1,
                                "column": column_index,
                                "raw": raw_candidate,
                                "value": candidate,
                            }
                            numeric.append(item)
                            if candidate < 0:
                                all_negative.append(item)
                                if candidate > -1:
                                    all_negative_subday.append(item)
                        headers.append(
                            {
                                "sheet": sheet.title,
                                "row": row_index,
                                "column": column_index,
                                "text": value,
                                "numeric_count_below": len(numeric),
                                "negative_values": [
                                    item["value"] for item in numeric if item["value"] < 0
                                ],
                                "negative_subday_values": [
                                    item["value"]
                                    for item in numeric
                                    if -1 < item["value"] < 0
                                ],
                            }
                        )
            workbook.close()
            records.append(
                {
                    "path": str(path),
                    "sha256": digest,
                    "physical_copies": duplicates[digest],
                    "headers": headers,
                }
            )
        except Exception as exc:
            errors.append(
                {
                    "path": str(path),
                    "sha256": digest,
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    result = {
        "physical_directional_workbooks": len(physical),
        "unique_directional_workbooks": len(unique),
        "unique_workbooks_with_slack_headers": sum(bool(row["headers"]) for row in records),
        "negative_slack_cells": all_negative,
        "negative_subday_slack_cells": all_negative_subday,
        "errors": errors,
        "workbooks": records,
        "oracle_available": bool(all_negative_subday),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
