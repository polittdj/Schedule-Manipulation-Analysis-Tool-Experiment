import org.mpxj.ProjectFile;
import org.mpxj.mpp.MPPReader;
import org.mpxj.reader.UniversalProjectReader;

public final class MpxjProbe {
    public static void main(String[] args) throws Exception {
        String path = args[0];
        try {
            ProjectFile universal = new UniversalProjectReader().read(path);
            System.out.println("universal=" + (universal == null ? "null" : universal.getTasks().size()));
        } catch (Throwable error) {
            System.out.println("universal-error=" + error);
            error.printStackTrace(System.out);
        }
        try {
            ProjectFile direct = new MPPReader().read(path);
            System.out.println("direct=" + (direct == null ? "null" : direct.getTasks().size()));
        } catch (Throwable error) {
            System.out.println("direct-error=" + error);
            error.printStackTrace(System.out);
        }
    }
}
