import org.mpxj.Duration;
import org.mpxj.GenericCriteria;
import org.mpxj.ProjectFile;
import org.mpxj.Task;
import org.mpxj.TaskField;
import org.mpxj.TestOperator;
import org.mpxj.TimeUnit;

/**
 * Independent MPXJ oracle for an MS Project saved-filter duration literal.
 *
 * The probe asks MPXJ's own GenericCriteria evaluator which task durations equal a literal
 * Duration(2, ELAPSED_DAYS), and prints the same values after MPXJ normalizes them to hours.
 */
public final class MpxjFilterDurationProbe {
    private static boolean evaluate(ProjectFile file, Task task, Duration literal) {
        GenericCriteria criteria = new GenericCriteria(file.getProjectProperties());
        criteria.setLeftValue(TaskField.DURATION);
        criteria.setOperator(TestOperator.EQUALS);
        criteria.setRightValue(0, literal);
        return criteria.evaluate(task, null);
    }

    public static void main(String[] args) {
        ProjectFile file = new ProjectFile();
        file.getProjectProperties().setMinutesPerDay(480);
        file.getProjectProperties().setMinutesPerWeek(2400);
        file.getProjectProperties().setDaysPerMonth(20);

        Task ordinaryTwoDays = file.addTask();
        ordinaryTwoDays.setName("ordinary-two-days");
        ordinaryTwoDays.setDuration(Duration.getInstance(2, TimeUnit.DAYS));

        Task elapsedTwoDays = file.addTask();
        elapsedTwoDays.setName("elapsed-two-days");
        elapsedTwoDays.setDuration(Duration.getInstance(2, TimeUnit.ELAPSED_DAYS));

        Task ordinarySixDays = file.addTask();
        ordinarySixDays.setName("ordinary-six-days");
        ordinarySixDays.setDuration(Duration.getInstance(6, TimeUnit.DAYS));

        Duration literal = Duration.getInstance(2, TimeUnit.ELAPSED_DAYS);
        System.out.println("literal=" + literal);
        System.out.println(
            "literal_hours=" + literal.convertUnits(TimeUnit.HOURS, file.getProjectProperties())
        );
        for (Task task : new Task[] {ordinaryTwoDays, elapsedTwoDays, ordinarySixDays}) {
            Duration duration = task.getDuration();
            System.out.println(
                task.getName()
                + " raw=" + duration
                + " hours=" + duration.convertUnits(TimeUnit.HOURS, file.getProjectProperties())
                + " equals_2ed=" + evaluate(file, task, literal)
            );
        }
    }
}
