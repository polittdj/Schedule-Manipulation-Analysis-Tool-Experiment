#!/usr/bin/env python3
"""Supplement P2/P6 with correct /api/dashboard epochs and semantic MPP repeatability.

The reviewed repository is imported read-only. Every fixture, cache, and output lives in the
external audit-artifacts tree.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any, Callable

from fastapi.testclient import TestClient

from performance_matrix import deep_size, synthetic_schedule
from schedule_forensics.importers.mspdi import parse_mspdi
from schedule_forensics.model.schedule import Schedule
from schedule_forensics.web.app import create_app
from schedule_forensics.web.state import SessionState


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def percentile_summary(values: list[float]) -> dict[str, Any]:
    ordered = sorted(values)
    return {
        "trials": len(values),
        "values": [round(value, 3) for value in values],
        "median": round(statistics.median(values), 3),
        "p95_nearest_rank": round(ordered[math.ceil(0.95 * len(ordered)) - 1], 3),
        "min": round(min(values), 3),
        "max": round(max(values), 3),
    }


def timed(operation: Callable[[], bytes], *, trials: int = 5, warmups: int = 1) -> dict[str, Any]:
    for _ in range(warmups):
        operation()
    elapsed: list[float] = []
    hashes: list[str] = []
    sizes: list[int] = []
    for _ in range(trials):
        started = time.perf_counter()
        payload = operation()
        elapsed.append((time.perf_counter() - started) * 1000)
        hashes.append(digest(payload))
        sizes.append(len(payload))
    return {
        "latency_ms": percentile_summary(elapsed),
        "payload_bytes": sizes,
        "output_hashes": hashes,
        "output_identical": len(set(hashes)) == 1,
    }


def cache_counts(state: SessionState) -> dict[str, int]:
    return {
        "schedules": len(state.schedules),
        "analyses": len(state.analyses),
        "cpms": len(state.cpms),
        "summaries": len(state.summaries),
        "dash_cores": len(state.dash_cores),
        "dash_cards": len(state.dash_cards),
        "scope_memos": len(state._scoped),
    }


def cache_sizes(state: SessionState) -> dict[str, int]:
    return {
        "state": deep_size(state),
        "schedules": deep_size(state.schedules),
        "analyses": deep_size(state.analyses),
        "cpms": deep_size(state.cpms),
        "summaries": deep_size(state.summaries),
        "dash_cores": deep_size(state.dash_cores),
        "dash_cards": deep_size(state.dash_cards),
        "scope_memos": deep_size(state._scoped),
    }


def independent_version_curve() -> list[dict[str, Any]]:
    curve: list[dict[str, Any]] = []
    for count in (1, 2, 4, 8):
        schedules = {
            f"v{index}": synthetic_schedule(
                250,
                name=f"Version {index}",
                project_title="Independent version curve",
                status_shift_days=index,
            )
            for index in range(count)
        }

        def cold() -> bytes:
            state = SessionState(schedules=dict(schedules))
            return TestClient(create_app(state)).get("/api/dashboard").content

        warm_state = SessionState(schedules=dict(schedules))
        warm_client = TestClient(create_app(warm_state))

        def warm() -> bytes:
            return warm_client.get("/api/dashboard").content

        curve.append(
            {
                "versions": count,
                "tasks_total": count * 250,
                "retained_schedule_bytes": deep_size(schedules),
                "cold_api_dashboard": timed(cold),
                "warm_api_dashboard": timed(warm),
                "warm_cache_counts": cache_counts(warm_state),
                "warm_cache_sizes": cache_sizes(warm_state),
            }
        )
    return curve


def epoch_growth(schedule: Schedule) -> dict[str, Any]:
    prior = schedule.model_copy(
        update={
            "source_file": "large-prior.xml",
            "status_date": schedule.status_date - dt.timedelta(days=7)
            if schedule.status_date
            else None,
        }
    )
    current = schedule.model_copy(update={"source_file": "large-current.xml"})
    state = SessionState(schedules={"prior": prior, "current": current})
    client = TestClient(create_app(state))

    baseline = client.get("/api/dashboard")
    baseline_hash = digest(baseline.content)
    before = {"counts": cache_counts(state), "sizes": cache_sizes(state)}

    uids = [
        task.unique_id
        for task in schedule.tasks
        if task.is_active and not task.is_summary
    ]
    targets = [uids[round(index * (len(uids) - 1) / 59)] for index in range(60)]
    latencies: list[float] = []
    statuses: list[int] = []
    response_hashes: list[str] = []
    for uid in targets:
        state.set_target(uid)
        started = time.perf_counter()
        response = client.get("/api/dashboard")
        latencies.append((time.perf_counter() - started) * 1000)
        statuses.append(response.status_code)
        response_hashes.append(digest(response.content))

    after_epochs = {"counts": cache_counts(state), "sizes": cache_sizes(state)}
    state.set_target(None)
    started = time.perf_counter()
    restored = client.get("/api/dashboard")
    restored_ms = (time.perf_counter() - started) * 1000
    after_restore = {"counts": cache_counts(state), "sizes": cache_sizes(state)}

    return {
        "versions": 2,
        "tasks_per_version": len(schedule.tasks),
        "epochs_exercised": len(targets),
        "expected_epoch_entries": 2 * (1 + len(targets)),
        "baseline_status": baseline.status_code,
        "target_statuses": sorted(set(statuses)),
        "target_latency_ms": percentile_summary(latencies),
        "unique_target_payload_hashes": len(set(response_hashes)),
        "baseline_hash": baseline_hash,
        "restored_hash": digest(restored.content),
        "restored_byte_identical": restored.content == baseline.content,
        "restored_latency_ms": round(restored_ms, 3),
        "before": before,
        "after_epochs": after_epochs,
        "after_restore": after_restore,
    }


def normalized_schedule_hash(path: Path) -> tuple[str, dict[str, Any]]:
    schedule = parse_mspdi(path)
    normalized = schedule.model_copy(
        update={
            "source_file": "normalized-direct-reader-output.xml",
            "name": "normalized-direct-reader-output",
        }
    )
    data = normalized.model_dump_json().encode()
    return digest(data), {
        "source": path.name,
        "raw_bytes": path.stat().st_size,
        "raw_sha256": digest(path.read_bytes()),
        "semantic_sha256": digest(data),
        "tasks": len(schedule.tasks),
        "relationships": len(schedule.relationships),
        "resources": len(schedule.resources),
        "calendars": len(schedule.calendars),
        "project_start": schedule.project_start.isoformat(),
        "project_finish": schedule.project_finish.isoformat()
        if schedule.project_finish
        else None,
        "status_date": schedule.status_date.isoformat() if schedule.status_date else None,
    }


def mpp_semantic_repeatability(cache_dir: Path) -> dict[str, Any]:
    files = sorted(cache_dir.glob("direct-*.xml"))
    rows: list[dict[str, Any]] = []
    hashes: list[str] = []
    for path in files:
        semantic_hash, row = normalized_schedule_hash(path)
        hashes.append(semantic_hash)
        rows.append(row)
    return {
        "files": rows,
        "raw_xml_identical": len({row["raw_sha256"] for row in rows}) == 1,
        "raw_sizes_identical": len({row["raw_bytes"] for row in rows}) == 1,
        "normalized_semantic_models_identical": len(set(hashes)) == 1,
        "unique_raw_hashes": len({row["raw_sha256"] for row in rows}),
        "unique_semantic_hashes": len(set(hashes)),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--large-xml", type=Path, required=True)
    parser.add_argument("--direct-cache", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    large = parse_mspdi(args.large_xml)
    result = {
        "method": {
            "trials": 5,
            "warmups": 1,
            "dashboard_endpoint": "/api/dashboard",
            "version_objects": "independently constructed; no model_copy sharing",
            "target_epochs": 60,
        },
        "independent_version_curve": independent_version_curve(),
        "target_epoch_growth": epoch_growth(large),
        "mpp_direct_reader_repeatability": mpp_semantic_repeatability(args.direct_cache),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
