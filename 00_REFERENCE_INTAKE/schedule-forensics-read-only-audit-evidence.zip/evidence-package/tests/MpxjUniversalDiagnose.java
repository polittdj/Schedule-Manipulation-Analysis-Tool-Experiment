import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.mpxj.mpp.MPPReader;
import org.mpxj.reader.UniversalProjectReader;

/** Mirror UniversalProjectReader's OLE temp-copy recognition path with visible diagnostics. */
public final class MpxjUniversalDiagnose {
    public static void main(String[] args) throws Exception {
        Path source = Path.of(args[0]);
        Path temp = Files.createTempFile("mpxj-universal-diagnose-", ".dat");
        try {
            try (InputStream input = Files.newInputStream(source);
                 OutputStream output = Files.newOutputStream(temp)) {
                input.transferTo(output);
            }
            System.out.println("java.io.tmpdir=" + System.getProperty("java.io.tmpdir"));
            System.out.println("source_bytes=" + Files.size(source));
            System.out.println("temp=" + temp);
            System.out.println("temp_bytes=" + Files.size(temp));
            try (POIFSFileSystem fs = new POIFSFileSystem(temp.toFile())) {
                System.out.println("root_entries=" + fs.getRoot().getEntryNames());
                System.out.println("mpp_format=" + MPPReader.getFileFormat(fs));
            }
            UniversalProjectReader reader = new UniversalProjectReader();
            try (UniversalProjectReader.ProjectReaderProxy proxy =
                    reader.getProjectReaderProxy(source.toFile())) {
                System.out.println(
                    "proxy=" + (proxy == null ? "null" : proxy.getProjectReader().getClass().getName())
                );
            }
        } finally {
            Files.deleteIfExists(temp);
        }
    }
}
